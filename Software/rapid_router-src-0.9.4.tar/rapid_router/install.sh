#!/bin/bash
#
# RAPID installation script
#

function check_file {
	if [ ! -e $1 ] ; then
		echo Missing a required file: $1
		exit 1
	fi
}

# $1=prompt string, $2=default response
# YN: 0=no, 1=yes
function yes_no {
	YN=0
	read -p "$1" ANS
	if [ "$ANS" == "" ] ; then
		YN=$2
	elif [ "$ANS" == "y" -o "$ANS" == "Y" ]; then
		YN=1
	elif [ "$ANS" == "yes" -o "$ANS" == "YES" -o "$ANS" = "Yes" ]; then
		YN=1
	fi

}

function tilde_sub {
	local ORIGSTRING="$1"
	local LEN=${#ORIGSTRING}
	local FIRSTCHAR=${ORIGSTRING:0:1}
	if [ "$FIRSTCHAR" != "~" -o "$HOME" == "" ] ; then
		NEWDIR="$ORIGSTRING"
		return
	fi
	if [ $LEN -eq 1 ] ; then
		NEWDIR="$HOME"
		return
	fi
	local SECONDCHAR=${ORIGSTRING:1:1}
	if [ "$SECONDCHAR" != "/" ] ; then
		NEWDIR="$ORIGSTRING"
		return
	fi
	local LASTPART=${ORIGSTRING:1}
	NEWDIR="${HOME}${LASTPART}"
}
	
function bin_dir {
	local PROMPT="Executables directory [${BINTARGET}]? "
	read -p "${PROMPT}" DIR
	if [ "$DIR" == "" ] ; then
		BINDIR=$BINTARGET
	else
		tilde_sub "$DIR"
		BINDIR=$NEWDIR
	fi
}

function ack_dir {
	local PROMPT="Acknowledgments directory [${ACKTARGET}]? "
	read -p "${PROMPT}" DIR
	if [ "$DIR" == "" ] ; then
		ACKDIR=$ACKTARGET
	else
		tilde_sub "$DIR"
		ACKDIR=$NEWDIR
	fi
}

function check_status {
	if [ $? -ne 0 ] ; then
		echo Failed
		exit 1
	fi
}

function create_dir {
	echo "Create directory $1 if it does not exist ..."
	if [ ! -e $1 ] ; then
		mkdir -p $1
		check_status
		if [ ! -e $1 ] ; then
			echo "Unable to create directory: $1"
		fi
	fi
}

function copy_file {
	cp -f $1 $2/.
	if [ $? -ne 0 ] ; then
		echo "Unable to copy file $1 to directory $2"
		exit 1
	fi
}

# Prompt for what to do.
SCRIPTPATH=`dirname $0`
FILE1="${SCRIPTPATH}/bin/RAPID.jar"
if [ ! -e $FILE1 ] ; then
	yes_no "RAPID does not appear to be built; build it [Y/n]? " 1
	if [ $YN -eq 1 ] ; then
		pushd $SCRIPTPATH >/dev/null
		make build
		if [ $? -ne 0 ] ; then
			echo "Unable to build RAPID"
			exit 1
		fi
		popd >/dev/null
		echo
	fi
fi
check_file $FILE1
FILE2="${SCRIPTPATH}/bin/RAPID"
check_file $FILE2
BINTARGET="/usr/local/rapid_router"
ACKTARGET="/var/rapid_router"
BINDIR=""
bin_dir
ACKDIR=""
yes_no "Create a directory for checkpointing delivery acknowledgments [Y/n]? " 1
if [ $YN -eq 1 ] ; then
	ack_dir
fi

# Get confirmation.
echo
echo "Install executables into directory: ${BINDIR}"
if [ "$ACKDIR" == "" ] ; then
	echo "Do not create a directory for checkpointing acknowledgments"
else
	echo "Directory for checkpointing acknowledgments: ${ACKDIR}"
fi
yes_no "Confirm [y/N]? " 0
if [ $YN -ne 1 ] ; then
	echo
	echo "Not confirmed; no files installed"
	echo
	exit 0
fi

# Install.
echo
create_dir $BINDIR
if [ "$ACKDIR" != "" ] ; then
	create_dir $ACKDIR
fi
echo "Copy files to $BINDIR ..."
copy_file $FILE1 $BINDIR
copy_file $FILE2 $BINDIR
if [ -e $SCRIPTPATH/rapid.conf.example ] ; then
	cp -f $SCRIPTPATH/rapid.conf.example $BINDIR/.
fi
if [ -e $SCRIPTPATH/log4j/log4j-1.2.15.jar ] ; then
	cp -f $SCRIPTPATH/log4j/log4j-1.2.15.jar $BINDIR/.
fi
echo Set execution permission ...
chmod +x $BINDIR/RAPID
if [ $? -ne 0 ] ; then
	echo "Error changing permissions on ${BINDIR}/RAPID"
	exit 1
fi
echo
echo RAPID successfully installed
echo
exit 0
