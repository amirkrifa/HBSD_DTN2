/**
 * RAPID exchanges meta data between peer routers. DTN keys off of a
 * predefined endpoint prefix defined for bundles destined for external
 * routers. When RAPID receives a bundle for its endpoint, this object's
 * eventDelivery() method is invoked. This object then invokes its thread
 * to read the bundle's data, and then calls the Policy Manager to act
 * upon the data. 
 * 
 * @author Brian Lynn <first initial last name at cs.umass.edu>
 * 
 * Copyright 2008 University of Massachusetts, Amherst
 * 
 * Licensed under the Apache License, Version 2.0 (the "License"); you may
 * not use this file except in compliance with the License. You may obtain
 * a copy of the License at
 *    http://www.apache.org/licenses/LICENSE-2.0
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * 
 * Funding for this project was provided by the Defense Advanced Research
 * Projects Agency (DARPA).
 * Distribution Statement A: Approved for public release; distribution
 * unlimited.
 */

import java.util.concurrent.LinkedBlockingQueue;
import java.util.NoSuchElementException;
import java.io.*;

class PeerListener implements Runnable {
	
	protected Handlers router = null;
	
	private Thread thread;
	
	private class PeerBundle {
		Bundle bundle;
		String payloadFile;
		PeerBundle(Bundle b) {
			bundle = b;
		}
	}
	
	private LinkedBlockingQueue <PeerBundle> msgQueue = null;
	
	/**
	 * Constructor. Create the queue used to wake up the thread.
	 */
	PeerListener(Handlers router) {
		this.router = router;
		msgQueue = new LinkedBlockingQueue<PeerBundle>();
	}
	
	/**
	 * Starts the listener thread.
	 */
	void init() {
		thread = new Thread(this, "listener");
		thread.start();
	}
		
	/**
	 * Called when a "bundle_delivery_event" is received. This event marks
	 * receipt of a bundle from a peer router. Create a PeerBundle object
	 * from data in the XML, then notify this class's thread of the bundle.
	 * 
	 * @param evtBundleDelivery XML root of the event.
	 * @param bundle Bundle object for the delivered bundle.
	 */
	void eventDelivery(XMLTree evtBundleDelivery, Bundle bundle) {
		try {
			// Make certain it is intended for the RAPID router. The endpoint
			// name is configurable.
			XMLTree bundleEvt =
				evtBundleDelivery.getChildElementRequired("bundle");
			XMLTree el;
			el = bundleEvt.getChildElementRequired("dest");
			String uri = el.getAttrRequired("uri");
			if (!uri.equals(RAPID.rapidRegistration)) {
				if (RAPID.log.enabled(Logging.DEBUG)) {
					RAPID.log.debug(
							"Ignoring router bundle not intended for RAPID: "
							+ uri);
				}
				return;
			}
			// Note the name of the file containing the payload. Invoke
			// the thread to run asynchronously.
			PeerBundle peerBundle = new PeerBundle(bundle);
			el = bundleEvt.getChildElementRequired("payload_file");
			peerBundle.payloadFile = el.getValue();
			msgQueue.offer(peerBundle);
		} catch (NoSuchElementException e) {
			if (RAPID.log.enabled(Logging.DEBUG)) {
				RAPID.log.debug("Problem with delivery XML message");
			}
			return;
		}
		
	}
	
	//////////////////////////// Listener Thread ////////////////////////////
	
	/**
	 * Main loop of the PeerListener thread. Wait for any peer bundles
	 * that have been received.
	 */
	public void run() {
		while (true) {
			PeerBundle peerBundle = null;
			try {
				peerBundle = msgQueue.take();
				if (peerBundle == null) {
					continue;
				}
				processPeerMessage(peerBundle);
			} catch (InterruptedException e) {
				// Do nothing.
			} catch (Exception e) {
				if (RAPID.log.enabled(Logging.ERROR)) {
					RAPID.log.error(
						"Unanticipated exception in PeerListener thread: " +
						e.getMessage());
				}
			}
		}
	}
	
	/**
	 * Called when a bundle has been received from a peer router.
	 * Read in the data, then call the policy manager to deal with it.
	 * The data store is requested to delete the bundle after we have
	 * read the data.
	 * 
	 * @param peerBundle Object that contains the Bundle object and
	 *    location of the payload file.
	 */
	void processPeerMessage(PeerBundle peerBundle) {
		File datFile = new File(peerBundle.payloadFile);
		try {
			// Get the data from the file.
			FileInputStream inFile = new FileInputStream(datFile); 
			int len = inFile.available();
			byte [] data = new byte[len];
			inFile.read(data);
			inFile.close();
			// Request that the bundle be deleted. This removes the file.
			RAPID.requester.requestDeleteBundle(peerBundle.bundle);
			// Notify the Policy Manager.
			router.policyMgr.metaDataReceived(peerBundle.bundle, data);
		} catch (Exception e) {
			// Failed to access file. Try to be helpful in isolating the
			// problem since it may be due to file or directory access
			// restrictions that are otherwise difficult to troubeleshoot.
			if (RAPID.log.enabled(Logging.ERROR)) {
				RAPID.log.error("Unable to access bundle payload: " +
						datFile.getPath());
				if (!datFile.getParentFile().canRead()) {
					RAPID.log.error(
							"Verify RAPID has read access to directory \"" +
							datFile.getParent() + "\"");
				} else if (datFile.exists()) {
					RAPID.log.error(
							"Verify RAPID has read access to files in directory \"" +
							datFile.getParent() + "\"");
				}
			}
			return;
		}
	}
	
}
