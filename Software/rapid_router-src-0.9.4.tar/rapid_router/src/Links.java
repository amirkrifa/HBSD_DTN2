/**
 * Manages the collection of known links. Information about a particular
 * link is maintained by the Link class.
 *  
 * @author Brian Lynn <first initial last name at cs.umass.edu>
 * 
 * Copyright 2008 University of Massachusetts, Amherst
 * 
 * Licensed under the Apache License, Version 2.0 (the "License"); you may
 * not use this file except in compliance with the License. You may obtain
 * a copy of the License at
 *    http://www.apache.org/licenses/LICENSE-2.0
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * 
 * Funding for this project was provided by the Defense Advanced Research
 * Projects Agency (DARPA).
 * Distribution Statement A: Approved for public release; distribution
 * unlimited.
 */

import java.util.HashMap;
import java.util.concurrent.locks.ReentrantReadWriteLock;

public class Links {
	
	protected Handlers router = null;
	
	private static final int DEFAULT_HASH_CAPACITY  = 16;
	
	private HashMap<String,Link> linkMap= null;
	private ReentrantReadWriteLock linksLock = null;
	
	/**
	 * Constructor: Get configuration values and create an empty table.
	 */
	Links(Handlers router) {
		this.router = router;
		int hashCapacity = 
			RAPID.routerConf.getInt("linksHashCapacity", DEFAULT_HASH_CAPACITY);
		linkMap = new HashMap<String,Link>(hashCapacity);
		linksLock = new ReentrantReadWriteLock();
	}
	
	/**
	 * Add a link to the list. We'll replace the current entry
	 * if it already exists. An add of an existing key should
	 * only be done if the Link value is null.
	 * 
	 * @param link Link to be added.
	 */
	private void add(Link link) {
		linksLock.writeLock().lock();
		if (linkMap.containsKey(link.id)) {
			linkMap.remove(link.id);
		}
		linkMap.put(link.id, link);
		linksLock.writeLock().unlock();
	}
	
	/**
	 * Creates and initializes a link, adding it to the list. We only
	 * create links from the main thread so we don't need to hold the
	 * lock from start to finish, just around the actual updates to the
	 * hash table.
	 * 
	 * @param evt Root of link created event.
	 * @return Created Link (null if failed).
	 */
	Link create(XMLTree evt) {
		// Get the link id.
		if (!evt.haveAttr("link_id")) {
			return null;
		}
		String id = evt.getAttr("link_id");
		// Do we already know about the id? The key may exist from
		// a previous incarnation, but the object should be null.
		Link link = getById(id);
		if (link != null) {
			if (RAPID.log.enabled(Logging.WARN)) {
				RAPID.log.warn(
						"Ignoringing request to create an existing link: " + id);
			}
			return null;
		}
		
		// Create the new link.
		link = new Link(this);
		if (!link.init(evt)) {
			return null;
		}
		add(link);
		router.policyMgr.linkCreated(link);
		return link;
	}
	
	/**
	 * Finds and removes a Link object. This method is called by
	 * delete() and does all of the work that should be synchronized
	 * within this class.
	 * 
	 * @param evt The XMLTree object representing the delete event.
	 * @return The link object
	 */
	private Link remove(XMLTree evt) {
		// Get the link id.
		if (!evt.haveAttr("link_id")) {
			return null;
		}
		String id = evt.getAttr("link_id");
		// Do we know about it?
		linksLock.writeLock().lock();
		Link link = linkMap.get(id);
		if (link == null) {
			linksLock.writeLock().unlock();
			if (RAPID.log.enabled(Logging.WARN)) {
				RAPID.log.warn(
						"Ignoringing request to delete a non-existent link: " + id);
			} 
			return null;
		}
		// Now remove it from the hash table.
		linkMap.remove(id);
		linksLock.writeLock().unlock();
		router.policyMgr.linkDeleted(link);
		return link;
	}
	
	/**
	 * Deletes a link. The link id key is not removed, but the object
	 * becomes null.
	 * 
	 * @param evt Root of link deleted event.
	 */
	void delete(XMLTree evt) {
		// Remove the link in a synchronized method.
		Link link = remove(evt);
		// Call into the link to delete itself without holding the
		// semaphore.
		link.deleted(evt);
	}
	
	/**
	 * Returns the number of links in the linkArray. This includes
	 * null links.
	 * 
	 * @return The number of links.
	 */
	int numLinks() {
		linksLock.readLock().lock();
		int sz = linkMap.size();
		linksLock.readLock().unlock();
		return sz;
	}
	
	/**
	 * Returns a Link given its name. Note that null can be returned
	 * even if the key exists.
	 * 
	 * @param id Name (id) of the link.
	 * @return Link object or null.
	 */
	Link getById(String id) {
		linksLock.readLock().lock();
		Link link = linkMap.get(id);
		linksLock.readLock().unlock();
		return link;
	}
}
