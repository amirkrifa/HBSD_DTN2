/**
 * Retains information about a known node.
 * 
 * Note: All associations between links and nodes, e.g. updating activeLink,
 * must be done from the main thread since the methods are not synchronized. 
 * 
 * @author Brian Lynn <first initial last name at cs.umass.edu>
 * 
 * Copyright 2008 University of Massachusetts, Amherst
 * 
 * Licensed under the Apache License, Version 2.0 (the "License"); you may
 * not use this file except in compliance with the License. You may obtain
 * a copy of the License at
 *    http://www.apache.org/licenses/LICENSE-2.0
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * 
 * Funding for this project was provided by the Defense Advanced Research
 * Projects Agency (DARPA).
 * Distribution Statement A: Approved for public release; distribution
 * unlimited.
 */

class Node {
	
	protected String eid = null;
	
	// Set when a link is open to this node.
	private Link activeLink = null;
	
	protected Object policyInfo = null;
	
	private Nodes nodeManager;
	
	/**
	 * Constructor. Should be called only by the Nodes class.
	 * 
	 * @param nodeManager Node class that manages this node.
	 * @param eid EID this node represents.
	 */
	Node(Nodes nodeManager, String eid) {
		this.nodeManager = nodeManager;
		this.eid = eid;
	}
	
	/**
	 * Sets the active link if it's not currently set.
	 * 
	 * @return True if set, false if not set because it's already set.
	 */
	boolean setLink(Link link) {
		boolean set = true;
		if (activeLink == null) {
			activeLink = link;
			if (RAPID.log.enabled(Logging.DEBUG)) {
				RAPID.log.debug("Associating: " + link.id + " and " + eid);
			}
		} else {
			if (RAPID.log.enabled(Logging.DEBUG)) {
				RAPID.log.debug("Not associating to " + eid +
					": " + link.id + " already associated to "
					+ link.remoteEID);
			}
			if (activeLink != link) {
				set = false;
			}
		}
		return set;
	}
	
	/**
	 * Clear the active link.
	 */
	void clearLink() {
		activeLink = null;
	}
	
	/**
	 * Indicates whether the node is associated with a specific link.
	 * 
	 * @param link Link in question.
	 * @return True if associated with the link, else false.
	 */
	boolean associated(Link link) {
		return (activeLink == link);
	}
	
	/**
	 * Indicates whether the node is associated with a link.
	 * 
	 * @return True if associated with some link, else false.
	 */
	boolean associated() {
		return (activeLink != null);
	}
	
	/**
	 * Finds a link that can take us to the destination EID. This can
	 * be an open link or a defined route. If found we call the link's
	 * conditionalUse() method. The link can choose to do several things:
	 * 
	 *    - Ignore the request, for example if the link is already in
	 *      contact with another EID.
	 *    - Associate this Node with the link, which could happen if the
	 *      link is in contact with the EID but this Node object is not
	 *      associated with the link. This might occur if the Node had
	 *      been previously associated with a different link (e.g. it
	 *      had been using an opportunistic link, or there are multiple
	 *      interfaces).
	 *    - Request that the link be opened. If that is the case then
	 *      this Node object does not get associated with the link, but
	 *      if the link does later open then the association may occur
	 *      at that time.
	 *      
	 * @param excludeLink If not null do not try to use the link
	 *    represented by this parameter.
	 * @return The found link, otherwise null.
	 */
	Link findLink(Link excludeLink) {
		if (activeLink != null) {
			return null;
		}
		Link link = nodeManager.router.routes.getLink(eid, excludeLink);
		if (link == null) {
			return null;
		}
		if (RAPID.log.enabled(Logging.DEBUG)) {
			RAPID.log.debug("Found link for EID " + eid + ": " + link.id);
		}
		link.conditionalUse(this);
		return link;
	}

	/**
	 * Called when a route has been added for this Node. If the Node is not
	 * already actively associated with a Link, possibly open the link. Even
	 * if there is no data to be sent it is generally a good idea to open a
	 * link to exchange meta data and possibly receive bundles.
	 *  
	 * @param link Associated Link object.
	 */
	void routeDefined(Link link) {
		if (activeLink == null) {
			link.conditionalUse(this);
		}
	}
	
	/**
	 * Called to notify the active link -- if there is one -- that a
	 * bundle has been queued. If there is a route for this EID, try
	 * to open the associated link if not already active. This method
	 * is normally called by the policy manager when a bundle has been
	 * queued.
	 * 
	 * @return The link to be notified, or null if no link.
	 */
	Link notifyLink() {
		if (activeLink != null) {
			// Wake up link.
			activeLink.bundleNotify();
			if (RAPID.log.enabled(Logging.DEBUG)) {
				RAPID.log.debug("Woke up link for EID: " + eid);
			}
			return activeLink;
		}
		return findLink(null);
	}
	
	/**
	 * The following mirror the LinkedQueue methods for each of the three
	 * defined bundle queues. However, it is the policy manager that
	 * actually defines, implements and manages the queues.
	 */
	
	boolean deliveryIsEmpty() {
		return nodeManager.router.policyMgr.deliveryIsEmpty(this);
	}
	
	boolean replicaIsEmpty() {
		return nodeManager.router.policyMgr.replicaIsEmpty(this);
	}
	
	boolean metadataIsEmpty() {
		return nodeManager.router.policyMgr.metaDataIsEmpty(this);
	}
	
	Bundle deliveryPoll() {
		return nodeManager.router.policyMgr.deliveryPoll(this);
	}
	
	Bundle replicaPoll() {
		return nodeManager.router.policyMgr.replicaPoll(this);
	}
	
	Bundle metadataPoll() {
		return nodeManager.router.policyMgr.metaDataPoll(this);
	}

}
