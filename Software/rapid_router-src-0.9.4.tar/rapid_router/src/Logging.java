/**
 * Logging
 * 
 * Interface for logging routines. The purpose for defining a logging
 * interface is, obviously, to allow for different implementations.
 * For example, a user may want to use a logging interface that captures
 * the XML traces to map where a bundle has been, or to create a file that
 * can be used for play back in simulations.
 * 
 * @author Brian Lynn <first initial last name at cs.umass.edu>
 * 
 * Copyright 2008 University of Massachusetts, Amherst
 * 
 * Licensed under the Apache License, Version 2.0 (the "License"); you may
 * not use this file except in compliance with the License. You may obtain
 * a copy of the License at
 *    http://www.apache.org/licenses/LICENSE-2.0
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * 
 * Funding for this project was provided by the Defense Advanced Research
 * Projects Agency (DARPA).
 * Distribution Statement A: Approved for public release; distribution
 * unlimited.
 */

interface Logging {
	
	/**
	 * Logging levels to be supported.
	 */
	static final int ALL     = -1;
	static final int TRACE   = 0;
	static final int DEBUG   = 1;
	static final int INFO    = 2;
	static final int WARN    = 3;
	static final int ERROR   = 4;
	static final int FATAL   = 5;
	static final int OFF     = 6;
	
	/**
	 * Called once to allow the logging implementation to configure itself.
	 */
	void conf();
	
	/**
	 * An overload of the above conf() method that allows a configuration
	 * file to be specified.
	 * 
	 * @param confFile The name of the configuration file.
	 */
	void conf(String confFile);
		
	/**
	 * Sets the logging level.
	 * 
	 * @param lev New level.
	 */
	void setLevel(int lev);
	
	/**
	 * @return Returns the current logging level.
	 */
	int getLevel();
	
	/**
	 * Indicates whether logging is enabled for the given level.
	 * 
	 * @param lev Level to check.
	 * @return True if enabled, otherwise false.
	 */
	boolean enabled(int lev);
		
	/**
	 * Logging write routines. It up to the implementation as to whether
	 * these routines strictly adhere to logging level.
	 * 
	 * @param message Message to be logged.
	 */
	void trace(String message);
	void debug(String message);
	void info(String message);
	void warn(String message);
	void error(String message);
	void fatal(String message);
}
