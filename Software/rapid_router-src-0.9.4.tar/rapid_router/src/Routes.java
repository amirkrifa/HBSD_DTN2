/**
 * This class maintains mapping of EIDs (nodes) to links. We define two
 * mappings:
 * 
 *    Persistent routes - These are defined either through the DTN
 *       configuration file or the dtnd console interface. These routes are
 *       persistent in that they exist regardless of the link state. We
 *       have implemented a simple routing scheme. We do not support any
 *       granularity finer than an EID, and we assume an EID has only one
 *       persistent route.
 *    Temporal routes - These routes are created whenever a link is opened,
 *       and deleted when the link is closed. A temporal route can reflect
 *       a persistent route that is open, i.e. the EID to Link mapping can
 *       exist in both the routeMap hash and the temporalList.
 * 
 * @author Brian Lynn <first initial last name at cs.umass.edu>
 * 
 * Copyright 2008 University of Massachusetts, Amherst
 * 
 * Licensed under the Apache License, Version 2.0 (the "License"); you may
 * not use this file except in compliance with the License. You may obtain
 * a copy of the License at
 *    http://www.apache.org/licenses/LICENSE-2.0
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * 
 * Funding for this project was provided by the Defense Advanced Research
 * Projects Agency (DARPA).
 * Distribution Statement A: Approved for public release; distribution
 * unlimited.
 */

import java.util.HashMap;
import java.util.ArrayList;
import java.util.NoSuchElementException;

class Routes {
	
	protected Handlers router = null;
	
	private HashMap <String,Link> routeMap = null;
	private ArrayList <TemporalRoute> temporalList = null;
	
	private class TemporalRoute {
		String eid;
		Link link;
		TemporalRoute(String eid, Link link) {
			this.eid = eid;
			this.link = link;
		}
	}
	
	Routes(Handlers router) {
		this.router = router;
		routeMap = new HashMap<String,Link>();
		temporalList = new ArrayList<TemporalRoute>();
	}
	
	/**
	 * Called when a "route_add_event" is received. Creates a mapping from
	 * the EID to the link. Note that the event contains a URI, which can
	 * have finer granularity than the EID. But we only support routes that
	 * map an EID to a link. Also note that Node objects are created at the
	 * first reference to an EID, so adding a route may result in a Node
	 * object being created. Finally, note that we expect only a single
	 * route per EID.
	 *  
	 * @param evtRouteAdd XMLTree object representing the event.
	 */
	void addRoute(XMLTree evtRouteAdd) {
		try {
			XMLTree el = evtRouteAdd.getChildElementRequired("route_entry");
			String linkName = el.getAttrRequired("link");
			el = el.getChildElementRequired("dest_pattern");
			String eid = eidFromURI(el.getAttrRequired("uri"));
			Node node = router.nodes.conditionalAdd(eid);
			Link link = router.links.getById(linkName);
			if (link == null) {
				if (RAPID.log.enabled(Logging.WARN)) {
					// Normally we might log this as an error, but it can
					// occur due to the route_report. We need link_report
					// to support link_ids.
					RAPID.log.warn(
							"Attempted to add a route using an unknown link: "
							+ linkName + " (ignored)");
				}
				return;
			}
			synchronized(this) {
				routeMap.put(eid, link);
			}
			// Notify the Node of the association. This can result in a
			// request to open the link.
			node.routeDefined(link);
			if (RAPID.log.enabled(Logging.DEBUG)) {
				RAPID.log.debug("Added route mapping EID " + eid + 
						" to link " + linkName);
			}
			return;
		} catch (NoSuchElementException e) {
			if (RAPID.log.enabled(Logging.ERROR)) {
				RAPID.log.error("Ill-formed route_add_event");
			}
			return;
		}
	}

	/**
	 * Called when a "route_delete_event" is received. Removes the mapping
	 * of the EID to the link.
	 *  
	 * @param evtRouteDelete XMLTree object representing the event.
	 */
	void deleteRoute(XMLTree evtRouteDelete) {
		try {
			XMLTree el = evtRouteDelete.getChildElementRequired("dest");
			String eid = eidFromURI(el.getAttrRequired("uri"));
			synchronized(this) {
				routeMap.remove(eid);
			}
			return;
		} catch (NoSuchElementException e) {
			if (RAPID.log.enabled(Logging.ERROR)) {
				RAPID.log.error("Ill-formed route_delete_event");
			}
			return;
		}
	}
	
	/**
	 * Called to process a route_report. The report is requested by RAPID in
	 * the event RAPID starts after dtnd.
	 * 
	 * @param event The root route_report element.
	 */
	void reportReceived(XMLTree event) {
		try {
			// For each route in the report, construct a route_add_event
			// and have the route added.
			int num = event.numChildElements();
			for (int n=0; n<num; n++) {
				XMLTree routeAddEvt = new XMLTree("route_add_event", 
						new HashMap<String,String>());
				routeAddEvt.addChildElement(event.getChildElement(n));
				addRoute(routeAddEvt);
			}
		} catch (Exception e) {
			if (RAPID.log.enabled(Logging.ERROR)) {
				RAPID.log.error("Ill-formed route_report received");
			}
			return;
		}
	}
	
	/**
	 * Called to add a temporal route. A temporal route is a created when
	 * a link opens to a particular node. This can be through discovery,
	 * etc.
	 * 
	 * @param eid The EID associated with the link.
	 * @param link The instance of the Link object for the open link.
	 */
	synchronized void addTemporalRoute(String eid, Link link) {
		temporalList.add(new TemporalRoute(eid, link));
		if (RAPID.log.enabled(Logging.DEBUG)) {
			RAPID.log.debug("Temporal route created: " +
					eid + " -> " + link.id);
		}
	}
	
	/**
	 * Removes a temporal route.
	 * 
	 * @param eid The EID of the temporal route.
	 * @param link The instance of the Link object for the open link.
	 */
	synchronized void deleteTemporalRoute(String eid, Link link) {
		int cnt = temporalList.size();
		for (int i=0; i<cnt; i++) {
			if (temporalList.get(i).eid.equals(eid)) {
				if (temporalList.get(i).link == link) {
					temporalList.remove(i);
					if (RAPID.log.enabled(Logging.DEBUG)) {
						RAPID.log.debug("Temporal route deleted: "
								+ eid + " -> " + link.id);
					}
					return;
				}
			}
		}
	}
	
	/**
	 * Gets the link for a given EID. We first look for temporal routes
	 * since they are already open. After that, we search for persistent
	 * routes. We only return a temporal route if it's not associated with
	 * a Node object.
	 * 
	 * @param eid EID to locate.
	 * @param excludeLink Link to exclude from the search (null if no 
	 *    exclusions).
	 * @return The link object, or null if there is no route.
	 */
	synchronized Link getLink(String eid, Link excludeLink) {
		Link link;
		// Look through the temporal routes.
		int cnt = temporalList.size();
		for (int i=0; i<cnt; i++) {
			if (temporalList.get(i).eid.equals(eid)) {
				link = temporalList.get(i).link;
				if (link == excludeLink) {
					continue;
				}
				if (!link.isAssociated()) {
					return link;
				}
			}
		}
		// No temporal route; what about a persistent route?
		link = routeMap.get(eid);
		if (link == null) {
			return null;
		}
		if (link != excludeLink) {
			return link;
		}
		return null;
	}
	
	
	/**
	 * Gets the temporal link for a given EID.
	 * 
	 * @param eid EID to locate.
	 * @param excludeLink Link to exclude from the search (null if no 
	 *    exclusions).
	 * @param notAssociated If set to true then a link matches on if
	 *    it's not currently associated with a node.
	 * @return The link object, or null if there is no route.
	 */
	synchronized Link getTemporalLink(String eid, Link excludeLink,
			boolean notAssociated) {
		int cnt = temporalList.size();
		for (int i=0; i<cnt; i++) {
			if (temporalList.get(i).eid.equals(eid)) {
				Link link = temporalList.get(i).link;
				if (link == excludeLink) {
					continue;
				}
				if (!notAssociated) {
					return link;
				}
				if (!link.isAssociated()) {
					return link;
				}
			}
		}
		return null;
	}
	

	/**
	 * Gets the temporal link for a given EID. We only return a temporal route
	 * if it's not associated with a Node object.
	 * 
	 * @param eid EID to locate.
	 * @param excludeLink Link to exclude from the search (null if no 
	 *    exclusions).
	 * @return The link object, or null if there is no route.
	 */
	Link getTemporalLink(String eid, Link excludeLink) {
		return getTemporalLink(eid, excludeLink, true);
	}
	
	/**
	 * Simplistic parser to return the EID from a URI. For our
	 * terminology here we refer to the EID has being the node
	 * within the URI. For example, URI dtn://node.dtn/abcdef
	 * would have EID dtn://node.dtn.
	 * 
	 * @return The EID.
	 */
	private String eidFromURI(String uri) {
		int cnt = 0;
		int sz = uri.length();
		int indx = 0;
		for (indx=0; indx<sz; indx++) {
			if (uri.charAt(indx) == '/') {
				if (++cnt == 3) {
					break;
				}
			}
		}
		return uri.substring(0, indx);
	}
	
}
