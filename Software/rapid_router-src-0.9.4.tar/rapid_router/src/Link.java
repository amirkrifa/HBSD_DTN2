/**
 * Maintains information about a known link. There is an instance of this
 * object for all created links. The Link object has a thread that dequeues
 * bundles from an associated Node object and transmits the bundles. Bundles
 * are queued by the Policy Manager.
 * 
 * When a link is opened, i.e. it is available for transmission, it will
 * have zero or one Node objects associated with the link. (A closed link
 * always has zero Node objects associated with it.) If a Node object is
 * associated, then the Link thread will transmit available bundles. A link
 * will have no associated node if there is another link open to the same
 * node and that link is already associated with the node. In other words,
 * when a link is open it is connected to a specific node, and RAPID uses
 * no more than one link to communicate with a given node at any point in
 * time. 
 * 
 * @author Brian Lynn <first initial last name at cs.umass.edu>
 * 
 * Copyright 2008 University of Massachusetts, Amherst
 * 
 * Licensed under the Apache License, Version 2.0 (the "License"); you may
 * not use this file except in compliance with the License. You may obtain
 * a copy of the License at
 *    http://www.apache.org/licenses/LICENSE-2.0
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * 
 * Funding for this project was provided by the Defense Advanced Research
 * Projects Agency (DARPA).
 * Distribution Statement A: Approved for public release; distribution
 * unlimited.
 */

import java.util.concurrent.*;
import java.util.NoSuchElementException;

class Link implements Runnable {
	
	// Link types
	static final int TYPE_ALWAYSON      = 0;
	static final int TYPE_ONDEMAND      = 1;
	static final int TYPE_SCHEDULED     = 2;
	static final int TYPE_OPPORTUNISTIC = 3;
	static final int TYPE_OTHER         = 4;
	
	// Link states. Do not assume the link goes from one state to the next.
	// But the ordinal values below are important.
	static final int STATE_NONEXTANT    = 0;
	static final int STATE_UNAVAILABLE  = 1;
	static final int STATE_AVAILABLE    = 2;
	static final int STATE_CLOSED       = 3;
	static final int STATE_OPENING      = 4;
	static final int STATE_OPEN         = 5;
	static final int STATE_BUSY         = 6;
	
	static final int DEFAULT_MAX_OUTSTANDING_SENDS = 10;
	
	private Links linkManager = null;
	protected Object policyInfo = null;
	protected Object linkPolicyInfo = null;
	
	// Set once and not changed: the link's id, i.e. name.
	protected String id = null;
	
	// Information about the link that is written outside of the Link
	// thread but read/copied by the thread.
	volatile protected int type = TYPE_OTHER;
	volatile protected int state = STATE_NONEXTANT;
	volatile protected String remoteEID = null;
	volatile protected int maxSendsOutstanding = DEFAULT_MAX_OUTSTANDING_SENDS;
	volatile protected int linkMaxSendsOutstanding = DEFAULT_MAX_OUTSTANDING_SENDS;
	volatile private Node currentNode = null;
	volatile private Node attachNode = null;
	volatile private boolean canAttach = false;
	
	// Information about the link maintained by the thread. This may not
	// match the externally visible values since the thread (and the router,
	// for that matter) run asynchronously.
	private int thrdState = STATE_NONEXTANT;
	private Node thrdCurrentNode; 
	private int waitPolicy;
	private boolean metaDataSent;
	
	// Mechanism used to synchronize the thread making copies of the
	// above values.
	private SynchronousQueue <Integer> syncQ = null;
	
	private XMLTree contactAttrs = null;
	// State should be taken from the state variables rather then this element.
	private XMLTree linkAttrs = null;
	private XMLTree clInfo = null;
	private String remoteAddr = null;

	private boolean openRequested = false;
	
	private Thread thread = null;
	
	private static final int ACTION_NONE = 0;
	private static final int ACTION_RUN  = 1;
	private static final int ACTION_STOP = 2;

	// For telling the thread to stop.
	private int action = ACTION_NONE;

	// Messages are externally queued here to wake up the link thread.
	private LinkedBlockingQueue <LinkMessage> msgQueue = null;
	
	// Message used to wake up the link thread. The type is used
	// only for debugging; the thread does not really care why it
	// was woken up.
	private class LinkMessage {
		static final int MSG_WAKEUP    = 0;
		static final int MSG_STATE     = 1;
		static final int MSG_BUNDLE    = 2;
		static final int MSG_TRANSMIT  = 3;
		static final int MSG_ATTACH    = 4;
		int type;
		LinkMessage() {
			type = MSG_WAKEUP;
		}
		LinkMessage(int what) {
			type = what;
		}
	}
	
	/**
	 * Constructor: Create queues for receiving control messages between
	 * the main and Link thread.
	 * 
	 * @param Instance of the Links class creating this link.
	 */
	Link(Links links) {
		linkManager = links;
		syncQ = new SynchronousQueue<Integer>();
		msgQueue = new LinkedBlockingQueue<LinkMessage>();
	}
	
	///////////////////////////// Link Thread //////////////////////////////
	
	/**
	 * Do any clean-up before terminating the thread. 
	 */
	private void finish() {
		msgQueue.clear();
	}
	
	/**
	 * Body of thread. Loop waiting for a message to arrive on
	 * the queue. Stop when the action variable changes to ACTION_STOP.
	 */
	public void run() {
		while (true) {
			// Wait for a message to arrive.
			LinkMessage msg = null;
			try {
				msg = msgQueue.take();
				// Have we been asked to stop the thread?
				if (action == ACTION_STOP) {
					finish();
					return;
				}
				if (msg != null) {
					// It doesn't matter what type of message woke us up, the
					// routine is the same: determine the state of the link,
					// see if we can act on any bundles. It's safe to delete all
					// messages from the msgQueue: the purpose of all messages
					// is to wake this thread up, not for the thread to act on
					// a specific message type.
					switch (msg.type) {
						case LinkMessage.MSG_BUNDLE:
						case LinkMessage.MSG_WAKEUP:
						case LinkMessage.MSG_STATE:
						case LinkMessage.MSG_TRANSMIT:
						case LinkMessage.MSG_ATTACH:
							if (RAPID.log.enabled(Logging.DEBUG)) {
								RAPID.log.debug("Link thread was woken up: " + id);
								if (thrdCurrentNode == null) {
									RAPID.log.debug("Link " + id + " is not associated with a node");
								} else {
									RAPID.log.debug("Link " + id + " is associated with a node: " + thrdCurrentNode.eid);
								}
							}
							msgQueue.clear();
							takeAction();
							break;
						default:
							if (RAPID.log.enabled(Logging.ERROR)) {
								RAPID.log.error("Unknown LinkMessage type dequeued");
							}
							break;
					}
				}
			} catch (InterruptedException e) {
				// Do nothing except wait for the next message.
			} catch (Exception e) {
				if (RAPID.log.enabled(Logging.ERROR)) {
					RAPID.log.error(
							"Unanticipated exception in Link thread: " +
							e.getMessage());
				}
			}
			finally {
				// Have we been asked to stop the thread?
				if (action == ACTION_STOP) {
					finish();
					return;
				}
				
			}
		}
	}
	
	/**
	 * Once awake, this is the link thread's primary loop. Look for changes in
	 * state, and send bundles if the conditions are appropriate.
	 */
	private void takeAction() {
		// We maintain a worst-case count of sends outstanding so that we don't
		// have to query for the actual value with each loop iteration.
		maxSendsOutstanding =
			linkManager.router.policyMgr.maxOutstandingTransmits(this,
					thrdCurrentNode, metaDataSent, linkMaxSendsOutstanding);
		int currentSends = maxSendsOutstanding;
		while (true) {
			// Determine the perceived state of the link.
			if (checkState()) {
				currentSends = maxSendsOutstanding;
			}
			// If the link is busy, stop.
			if (thrdState == STATE_BUSY) {
				return;
			}
			// Is the link associated with a node?
			if (thrdCurrentNode == null) {
				// Not associated, but can we associate?
				if (canAttach) {
					attachToNode();
					// Re-check state, we may or may net be associated.
					continue;
				}
				return;
			}
			// If the link is not open then we cannot use it. Request to open links
			// is handled elsewhere.
			if (thrdState < STATE_OPEN) {
				return;
			}
			// Make certain we don't already have the maximum number of sends
			// outstanding.
			if (currentSends >= maxSendsOutstanding) {
				maxSendsOutstanding =
					linkManager.router.policyMgr.maxOutstandingTransmits(this,
							thrdCurrentNode, metaDataSent, linkMaxSendsOutstanding);
				currentSends = 
					linkManager.router.policyMgr.outstandingTransmits(this, thrdCurrentNode);
				if (currentSends >= maxSendsOutstanding) {
					if (RAPID.log.enabled(Logging.DEBUG)) {
						RAPID.log.debug("Link is flow controlled: " +
								id + " (eid=" + thrdCurrentNode.eid + ")");
					}
					return;
				}
			}
			// Optimistically update the count of outstanding sends. This just
			// controls how often we query the Policy Manager for the real
			// count.
			currentSends++;
			// The order of sending is: meta data, bundles destined for the peer,
			// data to be replicated at the peer. However, the Policy Manager can
			// play any games with the queues that it wants.
			if (!sendBundle(Policy.QUEUE_METADATA)) {
				// Have we not yet sent meta data and, if not, are we supposed
				// to wait before sending any other bundles?
				if (!metaDataSent && (waitPolicy <= Policy.WAIT_METATDATA)) {
					if (RAPID.log.enabled(Logging.DEBUG)) {
						RAPID.log.debug("Waiting for meta data to be injected");
					}
					currentSends--;
					return;
				}
				// Try sending a bundle.
				if (!sendBundle(Policy.QUEUE_DELIVERY)) {
					if (!metaDataSent && (waitPolicy <= Policy.WAIT_DELIVERY)) {
						if (RAPID.log.enabled(Logging.DEBUG)) {
							RAPID.log.debug("Waiting for delivery queue or meta data to be injected");
						}
						currentSends--;
						return;
					}
					if (!sendBundle(Policy.QUEUE_REPLICA)) {
						currentSends--;
						if (RAPID.log.enabled(Logging.DEBUG)) {
							RAPID.log.debug("No bundles to be sent by link: " + id);
						}
						return;
					}
				}
			}
		}
	}
	
	/**
	 * Send a bundle. Notify the policy manager if there was a bundle
	 * that we requested be sent.
	 * 
	 * @param queue Queue to get the bundle from.
	 * @return True if there was data to be sent.
	 */
	private boolean sendBundle(int queue) {
		Bundle bundle;
		boolean toDest;
		boolean metaData;
		do  {
			bundle = null;
			toDest = false;
			metaData = false;
			// We ask the Node object for the bundle. (And the Node object
			// asks the Policy Manager.)
			switch (queue) {
				case Policy.QUEUE_METADATA:
					bundle = thrdCurrentNode.metadataPoll();
					if (bundle != null) {
						metaDataSent = true;
					}
					metaData = true;
					toDest = true;
					break;
				case Policy.QUEUE_DELIVERY:
					bundle = thrdCurrentNode.deliveryPoll();
					toDest = true;
					break;
				case Policy.QUEUE_REPLICA:
					bundle = thrdCurrentNode.replicaPoll();
					break;
				default:
					return false;
			}
			if (bundle == null) {
				return false;
			}
			// Though the Policy Manager ultimately gave us the bundle, we
			// provide an opportunity for the Policy Manager to veto sending
			// the bundle. This is because the Policy Manager may know that
			// a bundle shouldn't be sent (e.g., it is known to have been
			// delivered), yet the bundle still existed in the Node's
			// transmission queue. If the Policy Manager vetoes the bundle,
			// try to get another bundle.
			if (linkManager.router.policyMgr.shouldTransmit(this, bundle,
					thrdCurrentNode, queue)) {
				break;
			}
			if (RAPID.log.enabled(Logging.DEBUG)) {
				RAPID.log.debug("Link was told not to send a bundle");
			}
		} while (true);
		// Tell the Policy Manager before sending to ensure it knows about the
		// transmit before the completion.
		linkManager.router.policyMgr.bundleTransmitStart(this, thrdCurrentNode,
				bundle, toDest, metaData, queue);
		RAPID.requester.requestSendBundle(bundle, id,
				Requester.FWD_ACTION_COPY);
		return true;
	}
		
	/**
	 * Checks to see if the state of the link has changed since
	 * the last time we looked. We only synchronize state changes
	 * from/to the OPEN state with the main thread.
	 * 
	 * A note on the link state: When the main thread receives
	 * notification of a change in a link's state it sets the variable
	 * state and wakes up the link's thread. The link's thread then
	 * sets its state  (thrdState) to the value of state. There are
	 * a couple side effects of this:
	 *    1) state and thrdState may be inconsistent;
	 *    2) the "state" variable can potentially change multiple
	 *       times before thrdState becomes consistent.
	 * But that's OK if you remember that this router is built on
	 * an asynchronous interface and so "state" may be inconsistent
	 * with the actual state of the link as viewed by DTN.
	 * 
	 * However we do synchronize on a link transition to/from the
	 * OPEN state. When a link becomes OPEN then we need to make
	 * copies of some values pertaining to the link before acknowledging
	 * the open.
	 * 
	 * @return True if the state changed, else false.
	 */
	private boolean checkState() {
		// Read the state value. The read is an atomic operation.
		// Note that once we've read the state it can change again,
		// but that's permissible since we will check again.
		int newState = state;
		if (newState == thrdState) {
			// No change
			return false;
		}
		int prevState = thrdState;
		// Have we had a change to/from the OPEN state? If so, then
		// we need to synchronize.
		boolean sync;
		if (((newState >= STATE_OPEN) && (prevState < STATE_OPEN)) ||
				((prevState >= STATE_OPEN) && (newState <STATE_OPEN))) {
			sync = true;
		} else {
			sync = false;
		}
		// If the link is now open get the node (if any) that this link
		// is associated with. Also, indicate that we have yet to send
		// meta data and determine what to do if there is as yet no
		// meta data to be sent. Note that we can be going from busy
		// to open, in which case nothing has changed except that we
		// can start sending again.
		if (newState >= STATE_OPEN) {
			if ((newState == STATE_OPEN) && (prevState < STATE_OPEN)) {
				thrdCurrentNode = currentNode;
				metaDataSent = false;
				if (thrdCurrentNode != null) {
					waitPolicy =
						linkManager.router.policyMgr.waitPolicy(this, thrdCurrentNode);
				}
			}
		} else {
			// We may be closing and no longer attached to a node.
			if (sync) { 
				thrdCurrentNode = currentNode;
			}
		}
		thrdState = newState;
		if (sync) {
			if (RAPID.log.enabled(Logging.DEBUG)) {
				String s;
				if (newState >= STATE_OPEN) {
					s = "to open";
				} else {
					s = "to closed";
				}
				RAPID.log.debug("Link thread aware of state transition: " + s);
			}
			// Synchronize with the main thread.
			try {
				syncQ.put(new Integer(0));
			} catch (InterruptedException e) {
			}
		}
		if (RAPID.log.enabled(Logging.DEBUG)) {
			if (sync) {
				RAPID.log.debug("Link thread finished synchronization");
			}
			if (thrdCurrentNode == null) {
				RAPID.log.debug("Link " + id + " not associated with a node");
			} else {
				RAPID.log.debug("Link " + id + " associated with node: " +
						thrdCurrentNode.eid);
			}
		}
		return true;
	}
	
	/**
	 * Called when the link is open but no node was associated with the
	 * link by the router, yet the router now indicates a node object is
	 * ready to be associated. Do the association and synch up with the
	 * main thread. 
	 */
	private void attachToNode() {
		if (RAPID.log.enabled(Logging.DEBUG)) {
			RAPID.log.debug("Attempting to complete an association");
		}
		thrdCurrentNode = attachNode;
		canAttach = false;
		try {
			syncQ.put(new Integer(0));
		} catch (InterruptedException e) {	
		}
		if (RAPID.log.enabled(Logging.DEBUG)) {
			if (thrdCurrentNode != null) {
				RAPID.log.debug("Link " + id + " associated with node: " +
						thrdCurrentNode.eid);
			}
		}
		if (!metaDataSent) {
			waitPolicy =
				linkManager.router.policyMgr.waitPolicy(this, thrdCurrentNode);
		} else {
			waitPolicy = Policy.WAIT_ANY;
		}
	}
	
	///////////////////////////// Main Thread //////////////////////////////
			
	/**
	 * Start a thread to asynchronously handle events associated with
	 * this link.
	 */
	private void startThread() {
		thrdState = state;
		thread = new Thread(this, "link:" + id);
		action = ACTION_RUN;
		thread.start();
	}
	
	/**
	 * Called to notify the link thread that a bundle has been queued to
	 * the active node.
	 */
	void bundleNotify() {
		msgQueue.offer(new LinkMessage(LinkMessage.MSG_BUNDLE));
	}
	
	/**
	 * Called when the state of the link changes. A message is queued to
	 * wake up the thread. Note that subsequent events may cause the state
	 * to change such that when the thread gets this message the state may 
	 * be different from what it is now. The message is merely an indication
	 * that the thread should check to see if its state has changed. But,
	 * state changes to/from the OPEN state are synchronized.
	 * 
	 * Some notes on states. We only permit going to the busy state from the
	 * open state. We treat the available state as not open, though DTN will
	 * send us an "available event" when the link is no longer busy. In other
	 * words, a DTN available link really can be either open or not open. We
	 * handle an available event after a busy event by changing the link
	 * state back to open.
	 * 
	 * Some side effects of this method:
	 *    - If there is a node associated with the link and we're going
	 *      from an open to non-open state then un-associate the node and
	 *      link.
	 *    - If it's a transition between open and non-open (either direction)
	 *      then either create or delete a temporal route.
	 *    - If a transition from an open state to a non-open state and there
	 *      is a node associated with the link, determine if there is another
	 *      open link that can be used by the node.
	 * 
	 * @param newState State changing to. Note that writing this value to the
	 *    state variable is defined by Java as an atomic action.
	 */
	private void stateChange(int newState) {
		if (newState == state) {
			return;
		}
		Node prevNode = currentNode;
		boolean sync = false;
		boolean toOpenFromClosed = false;
		if ((newState >= STATE_OPEN) && (state < STATE_OPEN)) {
			// Non-open to open.
			sync = true;
			toOpenFromClosed = true;
			// Create a temporal route.
			linkManager.router.routes.addTemporalRoute(remoteEID, this);
			// Tell the policy manager about the link opening before
			// telling the thread.
			linkManager.router.policyMgr.linkOpened(this, currentNode);
		} else if ((state >= STATE_OPEN) && (newState <STATE_OPEN)) {
			// Open to non-open.
			sync = true;
			toOpenFromClosed = false;
			// Un-associate link and node.
			if (currentNode != null) {
				currentNode.clearLink();
				currentNode = null;
			}
			// Delete the temporal route.
			linkManager.router.routes.deleteTemporalRoute(remoteEID, this);
		}
		if (RAPID.log.enabled(Logging.DEBUG)) {
			if (sync) {
				RAPID.log.debug(
						"Notifying link thread of synchronizing state change: "
						+ newState);
			} else {
				RAPID.log.debug(
						"Notifying link thread of non-synchronizing state change: "
						+ newState);
			}
		}
		// Notify the Link thread of the state change. If the state change
		// requires synchronization with the thread, wait.
		state = newState;
		msgQueue.offer(new LinkMessage(LinkMessage.MSG_STATE));
		while (sync) {
			try {
				syncQ.take();
				break;
			} catch (InterruptedException e) {
				
			}
		}
		if (sync) {
			if (RAPID.log.enabled(Logging.DEBUG)) {
				RAPID.log.debug("Main thread finished synchronization");
			}
		}
		// Have we closed a previously open link?
		if (sync && !toOpenFromClosed) {
			boolean switched = false;
			if (prevNode != null) {
				// We went from an open to a non-open link. Is there another
				// link that the node can use?
				Link newLink = 
					linkManager.router.routes.getTemporalLink(prevNode.eid, this);
				if (newLink != null) {
					switched = newLink.associate(prevNode, true);
				}
				if (!switched) {
					// We were unable to switch to another link. Let the
					// policy manager know about the link closing. If we did
					// switch, the policy manager will be informed by the
					// new link's associate() method.
					linkManager.router.policyMgr.linkNotOpen(this, prevNode);
				} else {
					// We did switch and the policy manager has been informed.
					// We still need to tell the policy manager that this
					// link is no longer open.
					linkManager.router.policyMgr.linkNotOpen(this, null);
				}
			}
		}
	}
	
	/**
	 * Called when the link becomes available. Start the thread
	 * if not running. If the link had been busy then this probably
	 * means that it is open as opposed to able to be opened. If our
	 * current state is open then we just ignore the request because
	 * it probably means the link had been busy and no longer is busy
	 * (and for some reason we didn't realize that it was busy). Got
	 * that?
	 * 
	 * element Root XMLTree element for the event. 
	 */
	void available(XMLTree element) {
		if (thread == null) {
			startThread();
		}
		openRequested = false;
		if (state == STATE_OPEN) {
			return;
		}
		if (state == STATE_BUSY) {
			stateChange(STATE_OPEN);
		} else {
			stateChange(STATE_AVAILABLE);
		}
	}
	
	/**
	 * Called when the link becomes unavailable.
	 * 
	 * @param element Root XMLTree element for the event.
	 */
	void unavailable(XMLTree element) {
		openRequested = false;
		stateChange(STATE_UNAVAILABLE);
	}
	
	/**
	 * Called when the link is opened. Start thread if it's not
	 * running. If the state was busy then we treat this as "still
	 * open and no longer busy." (But in practice all that we have seen
	 * is an available event after a busy event if the link is still
	 * open.)
	 * 
	 * @param element Root XMLTree element for the event.
	 */
	void opened(XMLTree element) {
		openRequested = false;
		if (state >= STATE_OPEN) {
			if (state == STATE_BUSY) {
				stateChange(STATE_OPEN);
			}
			return;
		}
		// The following sets the remoteEID.
		findAndSaveAttributesContact(element);
		// Associate the destination node with this link. It's possible that
		// the node is already associated with another link, which can
		// happen due to opportunistic links. If that's the case we let the
		// link remain open with no associated node. We do have logic
		// elsewhere that allows a node to attach later on.
		Node openedNode = linkManager.router.nodes.conditionalAdd(remoteEID);
		if (!openedNode.setLink(this)) {
			openedNode = null;
		}
		currentNode = openedNode;
		if (thread == null) {
			startThread();
		}
		/*
		 * Once we change the state to OPEN the thread can re-read values
		 * about the link. At that point the thread makes its own copy of
		 * values that it will use. We wait until the thread tells us that
		 * it is aware of the state change.
		 */
		stateChange(STATE_OPEN);
	}
	
	/**
	 * Called when the link is closed.
	 * 
	 * @param element Root XMLTree element for the event.
	 */
	void closed(XMLTree element) {
		findAndSaveAttributesContact(element);
		if (thread == null) {
			startThread();
		}
		openRequested = false;
		stateChange(STATE_CLOSED);
	}

	/**
	 * Called when the link is noted as busy. We only allow the link
	 * to become busy if it had been open since we treat busy as a
	 * flow-control of an open link.
	 * 
	 * @param element Root XMLTree element for the event.
	 */
	void busy(XMLTree element) {
		openRequested = false;
		if (state != STATE_OPEN) {
			return;
		}
		stateChange(STATE_BUSY);
	}
	
	/**
	 * Called when the link is deleted. This should not be called
	 * directly, but instead be called by Links.delete(). If the link
	 * thread is running set the action variable to tell the thread
	 * to stop. When called, the Links class should have no more
	 * knowledge of this instance of the link.
	 * 
	 * @param element Root XMLTree element for the event.
	 */
	protected void deleted(XMLTree element) {
		if (thread == null) {
			return;
		}
		openRequested = false;
		action = ACTION_STOP;
		stateChange(STATE_NONEXTANT);
	}
	
	/**
	 * Called when data sent by this link has been transmitted. The policy
	 * manager does most of the work. When we're done calling the policy
	 * manager we wake up the link thread since it may be flow controlled
	 * on the number of bundles outstanding.
	 * 
	 * @param id Local id of the bundle.
	 * @param bytesSent Total bytes sent.
	 * @param bytesReliable Bytes reliably sent.
	 */
	void dataTransmitted(Long id, int bytesSent, int bytesReliable) {
		linkManager.router.policyMgr.bundleTransmitStop(this, currentNode,
				id, bytesSent, bytesReliable);
		msgQueue.offer(new LinkMessage(LinkMessage.MSG_STATE));
	}
	
	/**
	 * Called to determine if this link is open and associated with a Node
	 * object.
	 * 
	 * @return True if associated and open, else false.
	 */
	boolean isAssociated() {
		if ((state < STATE_OPEN) || (currentNode == null)) {
			return false;
		}
		return true;
	}
	
	/**
	 * Called to do the association of a Node to this link if this link is
	 * currently open. This is typically done when two links had been open
	 * to the same node, but the node had been active on the other link.
	 * Presumably, the other link is now closed while this link remains open.
	 * 
	 * @param node Node to be associated.
	 * @param switching If true, then this method is being called by the
	 *    link that is closing, otherwise this method is being called by the
	 *    node issuing a conditional open.
	 * @return True if an association was made, else false.
	 */
	boolean associate(Node node, boolean switching) {
		if (RAPID.log.enabled(Logging.DEBUG)) {
			if (switching) {
				RAPID.log.debug("associate() has been called for new node: "
						+ node.eid + " (switching=true)");
			} else {
				RAPID.log.debug("associate() has been called for new node: "
						+ node.eid + " (switching=false)");
			}
		}
		// Link must be open to the node!
		if ((state < STATE_OPEN) || (!remoteEID.equals(node.eid))) {
			return false;
		}
		// This link is open to the node so we can begin using the link.
		// We synchronize this action with the link thread:
		//   - assign the node object to a global variable
		//   - set a boolean indicating a node is available
		//   - have the node associate with this link
		//   - wake up the link thread
		//   - tell the policy manager about the switch if switching
		//   - wait for a response from the link thread
		//   - clear variables
		//   - tell the policy manager about the new association if
		//     switched is not set
		attachNode = node;
		canAttach = true;
		if (switching) {
			node.setLink(this);
			linkManager.router.policyMgr.linkSwitched(this, node);
		}
		msgQueue.offer(new LinkMessage(LinkMessage.MSG_ATTACH));
		while (true) {
			try {
				syncQ.take();
				break;
			} catch (InterruptedException e) {
			}
		}
		canAttach = false;
		attachNode = null;
		if (!switching) {
			linkManager.router.policyMgr.linkAssociated(this, node);
		}
		return true;
	}
	
	/**
	 * Called to request that a Link associate with a particular Node.
	 * If the link is already open and in contact with a different EID
	 * then the request is ignored. If the link is in contact with the EID
	 * but not already associated with the Node object that represents
	 * the EID, then make the association. Otherwise, if this is a link
	 * that we can request to have opened, request that the link be
	 * opened. If and when the link is opened, an association to the Node
	 * object will be made. 
	 * 
	 * @param node Node object and likely caller. There should be a
	 *    route between this link and the node, either persistent or
	 *    temporal. 
	 */
	void conditionalUse(Node node) {
		if (RAPID.log.enabled(Logging.DEBUG)) {
			RAPID.log.debug("conditionalUse() called for link " +
					id + " by EID " + node.eid);
		}
		if (currentNode != null) {
			// Already servicing another Node.
			return;
		}
		if (associate(node, false)) {
			// This shouldn't normally occur; associate() should be
			// called when the previously associated link closes.
			return;
		}
		// Is there already an open request to DTN pending?
		if (openRequested) {
			return;
		}
		// Allow the policy manager to decide whether to open the link.
		if (linkManager.router.policyMgr.requestLinkOpen(this, node)) {
			// Make a request to DTN that the link be opened. Mark that
			// we have a request outstanding (the value gets set to false
			// whenever we receive a link event).
			RAPID.requester.requestOpenLink(id);
			openRequested = true;
		}
	}
	
	/**
	 * Requests that the link be opened. This method is typically used
	 * by the policy manager to open a link.  
	 */
	void requestOpen() {
		// Do we already have an open request pending?
		if (openRequested) {
			return;
		}
		// Only states we assume we can request an open from.
		if ((state != STATE_AVAILABLE) && (state != STATE_CLOSED)){
			return;
		}
		// Only types we assume we request an open for.
		if ((type != TYPE_ALWAYSON) && (type != TYPE_ONDEMAND)) {
			return;
		}
		// Send a request to open the link to DTN and mark the
		// link as having a request outstanding. We expect DTN to
		// eventually respond with something, e.g. this link is
		// unavailable or open, and we mark the request as not being
		// outstanding whenever we hear something.
		RAPID.requester.requestOpenLink(id);
		openRequested = true;
	}
			
	/**
	 * Initialize a Link given an event. The creation and initialization of
	 * a link is normally done via the create() method of the Links class.
	 * 
	 * @param evtLinkCreated link_created_event as the root of a tree.
	 * return True if initialized ok, else false.
	 */
	protected boolean init(XMLTree evtLinkCreated) {
		// There should be an id, i.e. the link should be named.
		if (evtLinkCreated.haveAttr("link_id")) {
			id = evtLinkCreated.getAttr("link_id");
		} else {
			return false;
		}
		// One child element should be the link attributes (link_attr).
		// Find it and get the attributes that we initially care about.
		// Save the entire element for possible future use.
		try {
			XMLTree el = evtLinkCreated.getChildElementRequired("link_attr");
			if (!parseLinkAttr(el)) {
				return false;
			}
			storeLinkElement(el);
			findAndSaveAttributesCLinfo(el);
			if (state >= STATE_AVAILABLE) {
				startThread();
			}
			return true;
		} catch (NoSuchElementException e) {
			return false;
		}
	}
	
	/**
	 * Gets pertinent information from the link_attr element.
	 * 
	 * @param element Element as represented by the XMLTree class.
	 * @return True if required attributes exist, else false.
	 */
	private boolean parseLinkAttr(XMLTree element) {
		try {
			String str = element.getAttrRequired("type");
			type = whatType(str);
			str = element.getAttrRequired("state");
			state = whatState(str);
			return true;
		} catch (NoSuchElementException e) {
			return false;
		}
	}
	
	/**
	 * Converts a String type value to an integer value.
	 * 
	 * @param str String value.
	 * @return Integer value.
	 */
	private int whatType(String str) {
		if (str.equals("alwayson")) {
			return TYPE_ALWAYSON;
		}
		if (str.equals("ondemand")) {
			return TYPE_ONDEMAND;
		}
		if (str.equals("scheduled")) {
			return TYPE_SCHEDULED;
		}
		if (str.equals("opportunistic")) {
			return TYPE_OPPORTUNISTIC;
		}
		return TYPE_OTHER;
	}
	
	/**
	 * Converts a String state value to an integer value.
	 * 
	 * @param str String value.
	 * @return Integer value.
	 */
	private int whatState(String str) {
		if (str.equals("available")) {
			return STATE_AVAILABLE;
		}
		if (str.equals("open")) {
			return STATE_OPEN;
		}
		if (str.equals("opening")) {
			return STATE_OPENING;
		}
		if (str.equals("busy")) {
			return STATE_BUSY;
		}
		return STATE_UNAVAILABLE;
	}
	
	/**
	 * Called when a "contact_attribute_changed_event" message is received.
	 * Stores away the new contact attributes. Also stores new link and
	 * clinfo attributes if they also exist.
	 * 
	 * @param evtContactAttrsChanged Root contact_attribute_changed_event
	 *    element.
	 */
	void contactAttrsChanged(XMLTree evtContactAttrsChanged) {
		findAndSaveAttributesContact(evtContactAttrsChanged);
	}
	
	/**
	 * Called when a "link_attribute_changed_event" message is received.
	 * Stores away the new link attributes. Also stores new clinfo
	 * attributes if they exist.
	 * 
	 * @param evtContactAttrsChanged Root link_attribute_changed_event
	 *    element.
	 */
	void linkAttrsChanged(XMLTree evtLinkAttrsChanged) {
		findAndSaveAttributesLink(evtLinkAttrsChanged);
	}
	
	/**
	 * Search for a "contact_attr" element as a direct child element. If
	 * found, save it. Also, look and see if it has a "link_attr" element
	 * as a child.
	 * 
	 * @param event Root event where the contact_attr is expected to be a
	 *    direct child.
	 */
	private void findAndSaveAttributesContact(XMLTree event) {
		try {
			XMLTree el = event.getChildElementRequired("contact_attr");
			storeContactElement(el);
			findAndSaveAttributesLink(el);
		} catch (NoSuchElementException e) {
			
		}
	}
		
	/**
	 * Search for a "link_attr" element as a direct child element. If
	 * found, save it. Also, look and see if it has a "clinfo" element
	 * or "remote_eid" as a child.
	 * 
	 * @param event Root event where the link_attr is expected to be a
	 *    direct child.
	 */
	private void findAndSaveAttributesLink(XMLTree event) {
		try {
			XMLTree el = event.getChildElementRequired("link_attr");
			storeLinkElement(el);
			findAndSaveAttributesCLinfo(el);
			findAndSaveAttributesRemoteEID(el);
		} catch (NoSuchElementException e) {
			
		}
	}
	
	/**
	 * Search for a "clinfo" element as a direct child element. If
	 * found, save it.
	 * 
	 * @param event Root event where the clinfo is expected to be a
	 *    direct child.
	 */
	private void findAndSaveAttributesCLinfo(XMLTree event) {
		try {
			XMLTree el = event.getChildElementRequired("clinfo");
			storeCLinfoElement(el);
			maxSendsOutstanding = DEFAULT_MAX_OUTSTANDING_SENDS;
			linkMaxSendsOutstanding = DEFAULT_MAX_OUTSTANDING_SENDS;
			maxSendsOutstanding = new Integer(el.getAttrRequired("busy_queue_depth"));
			linkMaxSendsOutstanding = maxSendsOutstanding;
			remoteAddr = el.getAttrRequired("remote_addr");
		} catch (NoSuchElementException e) {
			
		}
	}
	
	/**
	 * Search for a "remote_eid" element as a direct child element. If
	 * found, save the "uri" attribute.
	 * 
	 * @param event Root event where the remote_eid is expected to be a
	 *    direct child.
	 */
	private void findAndSaveAttributesRemoteEID(XMLTree event) {
		try {
			XMLTree el = event.getChildElementRequired("remote_eid");
			String uri = el.getAttrRequired("uri");
			if (remoteEID == null) {
				remoteEID = uri;
			} else if (!uri.equals(remoteEID)) {
				remoteEID = uri;
			}
		} catch (NoSuchElementException e) {
			
		}
	}
	
	/**
	 * Saves the contact_attr element.
	 * 
	 * @param element XML element to be saved.
	 */
	private void storeContactElement(XMLTree element) {
		contactAttrs = element;
	}
	
	/**
	 * Returns the stored contact_attr element.
	 * 
	 * @return XML element.
	 */
	XMLTree getContactElement() {
		return contactAttrs;
	}
	
	/**
	 * Saves the link_attr element.
	 * 
	 * @param element XML element to be saved.
	 */
	private void storeLinkElement(XMLTree element) {
		linkAttrs = element;
	}
	
	/**
	 * Returns the defined remote address for the link.
	 * 
	 * @return Remote address, as obtained from the <clinfo> element.
	 */
	String getRemoteAddr() {
		return remoteAddr;
	}
	
	/**
	 * Returns the stored link_attr element.
	 * 
	 * @return XML element.
	 */
	XMLTree getLinkElement() {
		return linkAttrs;
	}
	
	/**
	 * Saves the clinfo element.
	 * 
	 * @param element XML element to be saved.
	 */
	private void storeCLinfoElement(XMLTree element) {
		clInfo = element;
	}
	
	/**
	 * Returns the stored clinfo element.
	 * 
	 * @return XML element.
	 */
	XMLTree getCLinfoElement() {
		return clInfo;
	}

}
