/**
 * This utility class deals with the Global Bundle or Fragment ID (GBOF-ID),
 * which uniquely identifies a bundle. The BPA uses a local ID, though the
 * GBOD-ID is also always available. The local id, of course, cannot be
 * used when talking to a peer router on another node.
 * 
 * Throughout RAPID we use a "GBOF hash" to reference bundles. The GBOF hash
 * is a Java String containing the values that compose the GBOF-ID, though
 * in a slightly more compact format than the full XML. To make things more
 * confusing, the GBOF hash is sometimes referred to as the the GBOF key or
 * the bundle key. 
 * 
 * @author Brian Lynn <first initial last name at cs.umass.edu>
 * 
 * Copyright 2008 University of Massachusetts, Amherst
 * 
 * Licensed under the Apache License, Version 2.0 (the "License"); you may
 * not use this file except in compliance with the License. You may obtain
 * a copy of the License at
 *    http://www.apache.org/licenses/LICENSE-2.0
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * 
 * Funding for this project was provided by the Defense Advanced Research
 * Projects Agency (DARPA).
 * Distribution Statement A: Approved for public release; distribution
 * unlimited.
 */

class GBOF {
	
	// Seconds between January 1, 1970 (standard epoch) and January 1, 2000
	// (DTN epoch).
	private static final int DELTA1970_SECONDS = 946684800;

	/**
	 * Generates a "gbofIdType" XML element.
	 * 
	 * @param bundle Bundle object.
	 * @return XML element.
	 */
	static String xmlFromBundle(Bundle bundle) {
		String xml = "<gbof_id creation_ts=\"" + bundle.creationTimestamp;
		xml += "\" frag_length=\"" + bundle.fragLength +
			"\" frag_offset=\"" + bundle.fragOffset;
		if (bundle.isFragment) {
			xml += "\" is_fragment=\"true\">";
		} else {
			xml += "\" is_fragment=\"false\">";
		}
		xml += "<source uri=\"" + bundle.sourceURI + "\"/></gbof_id>";
		return xml;
	}
	
	
	/**
	 * Generates a "gbofIdType" XML element.
	 * 
	 * @param timestamp Creation time stamp.
	 * @param len Length of bundle.
	 * @param offset Bundle offset.
	 * @param frag Whether it is a fragment.
	 * @param uri The source URI.
	 * @return The XML element.
	 */
	static String xmlFromParms(long timestamp, int len, int offset, boolean frag, String uri) {
		String xml = "<gbof_id creation_ts=\"" + timestamp;
		xml += "\" frag_length=\"" + len +
			"\" frag_offset=\"" + offset;
		if (frag) {
			xml += "\" is_fragment=\"true\">";
		} else {
			xml += "\" is_fragment=\"false\">";
		}
		xml += "<source uri=\"" + uri + "\"/></gbof_id>";
		return xml;
	}
	
	/**
	 * This function returns a string derived from the values that
	 * compose a GBOF-ID. This string is then used as a key to locate
	 * the bundle.
	 * 
	 * @param bundle Bundle object.
	 * @return The generated key.
	 */
	static String keyFromBundleObject(Bundle bundle) {
		return makeKey(bundle.creationTimestamp, bundle.fragLength,
				bundle.fragOffset, bundle.isFragment, bundle.sourceURI);
	}
	
	/**
	 * Returns the GBOF key associated with a bundle. This value is stored
	 * in the bundle when the bundle is created so we do not need to 
	 * derive it. The caller could simply read the value in the Bundle
	 * object if it wanted to.
	 * 
	 * @param bundle The Bundle object.
	 * @return The hash key.
	 */
	static String keyFromBundle(Bundle bundle) {
		return bundle.gbofKey;
	}
	
	/**
	 * Given a "gbofIdType," generate the key used to locate the bundle in the
	 * bundles hash.
	 * 
	 * @param element The "gbof_id" XML element.
	 * @return The generated key.
	 */
	static String keyFromXML(XMLTree element) {
		try {
			XMLTree el = element.getChildElementRequired("source");
			return makeKey(element.getAttrRequired("creation_ts"),
					element.getAttrRequired("frag_length"),
					element.getAttrRequired("frag_offset"),
					new Boolean(element.getAttrRequired("is_fragment")).booleanValue(),
					el.getAttrRequired("uri"));
		} catch (Exception e) {
			return null;
		}
	}
	
	/**
	 * Returns a hash key given the parsed values from a "gbofIdType"
	 * element.
	 * .
	 * @param timestamp Creation time stamp.
	 * @param len Length of bundle.
	 * @param offset Bundle offset.
	 * @param frag Whether it is a fragment.
	 * @param uri The source URI.
	 * @return The key.
	 */
	static String keyFromParms(final String timestamp, final String len,
			final String offset, final String frag, final String uri) {
		return makeKey(timestamp, len, offset,
				new Boolean(frag).booleanValue(), uri);
	}
	
	/**
	 * Returns a hash key given the parsed values from a "gbofIdType"
	 * element.
	 * .
	 * @param timestamp Creation time stamp.
	 * @param len Length of bundle.
	 * @param offset Bundle offset.
	 * @param frag Whether it is a fragment.
	 * @param uri The source URI.
	 * @return The key.
	 */
	static String keyFromParms(long timestamp, int len, int offset,
			boolean frag, String uri) {
		return makeKey(timestamp, len, offset,
				new Boolean(frag).booleanValue(), uri);
	}
	
	/**
	 * Generates the unique key given the required values. This is essentially
	 * a more compact version of the XML.
	 * 
	 * @param ts Creation time stamp.
	 * @param len Length of bundle.
	 * @param offset Bundle offset.
	 * @param frag Whether it is a fragment.
	 * @param uri The source URI.
	 * @return The key.
	 */
	private static String makeKey(final String ts, final String len,
			final String offset, final boolean frag, final String uri) {
		String binaryFrag;
		if (frag) {
			binaryFrag = ":1";
		} else {
			binaryFrag = ":0";
		}
		return ts + "[" + uri + "]"	+ offset + "+" + len + binaryFrag;
		
	}

	/**
	 * Overloaded method for creating a bundle key.
	 * 
	 * @param ts Creation time stamp.
	 * @param len Length of bundle.
	 * @param offset Bundle offset.
	 * @param frag Whether it is a fragment.
	 * @param uri The source URI.
	 * @return The key.
	 */
	private static String makeKey(long ts, int len, int offset, boolean frag,
			String uri) {
		return makeKey(new Long(ts).toString(), new Integer(len).toString(),
				new Integer(offset).toString(),	frag, uri);
	}
	
	/**
	 * Simplistic parser to return the EID from a URI.
	 * 
	 * @param The URI to be parsed.
	 * @return The EID.
	 */
	static String eidFromURI(final String uri) {
		if (!uri.startsWith("dtn://")) {
			return null;
		}
		int cnt = 0;
		int sz = uri.length();
		int indx = 0;
		for (indx=0; indx<sz; indx++) {
			if (uri.charAt(indx) == '/') {
				if (++cnt == 3) {
					break;
				}
			}
		}
		return uri.substring(0, indx);
	}
	
	/**
	 * Called to calculate the expiration time of a bundle.
	 * 
	 * @param timestamp GBOF creation time.
	 * @param deltaSeconds Seconds after creation the bundle expires.
	 * @return GMT epoch milliseconds the bundle is to expire (i.e. something
	 *    that can be compared against System.currentTimeMillis()).
	 */
	static long calculateExpiration(long timestamp, long deltaSeconds) {
		// The seconds since January 1, 2000 are in the high order 32 bits
		// of the creation time stamp found in the GBOF. Since epoch time
		// is since January 1, 1970 we add in the delta.
		long epochSeconds = (timestamp >> 32) + DELTA1970_SECONDS;
		// Now add the expiration seconds and convert it to milliseconds.
		return ((epochSeconds + deltaSeconds) * 1000) + 999;
	}
	
	/**
	 * Calculates the creation time of a bundle given its GBOF time stamp.
	 * 
	 * @param timestamp GBOF creation time.
	 * @return GMT epoch seconds of when the bundle was created.
	 */
	static long creationSeconds(long timestamp) {
		return (timestamp >> 32) + DELTA1970_SECONDS;
	}

}
