/**
 * SAX handler, contains methods called by the XML parser. A tree
 * object is created that represents the parsed XML document.
 * When the end of the document is encountered the appropriate 
 * router method is called.
 *
 * @author Brian Lynn <first initial last name at cs.umass.edu>
 * 
 * Copyright 2008 University of Massachusetts, Amherst
 * 
 * Licensed under the Apache License, Version 2.0 (the "License"); you may
 * not use this file except in compliance with the License. You may obtain
 * a copy of the License at
 *    http://www.apache.org/licenses/LICENSE-2.0
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * 
 * Funding for this project was provided by the Defense Advanced Research
 * Projects Agency (DARPA).
 * Distribution Statement A: Approved for public release; distribution
 * unlimited.
 */

import org.xml.sax.helpers.DefaultHandler;
import org.xml.sax.*;
import java.util.Stack;
import java.util.HashMap;

class RAPID_SAX extends DefaultHandler {
	
	private XMLTree xmlRoot = null;
	private Stack <XMLTree>elementStack = null;
	
	private Handlers intf = null;
	private HashMap<String, Integer> eventHash = null;
	
	// All known events that we may receive.
	private static final int BUNDLE_RECEIVED_EVENT           = 0;
	private static final int DATA_TRANSMITTED_EVENT          = 1;
	private static final int BUNDLE_DELIVERED_EVENT          = 2;
	private static final int BUNDLE_DELIVERY_EVENT           = 3;
	private static final int BUNDLE_SEND_CANCELLED_EVENT     = 4;
	private static final int BUNDLE_EXPIRED_EVENT            = 5;
	private static final int BUNDLE_INJECTED_EVENT           = 6;
	private static final int LINK_OPENED_EVENT               = 7;
	private static final int LINK_CLOSED_EVENT               = 8;
	private static final int LINK_CREATED_EVENT              = 9;
	private static final int LINK_DELETED_EVENT              = 10;
	private static final int LINK_AVAILABLE_EVENT            = 11;
	private static final int LINK_UNAVAILABLE_EVENT          = 12;
	private static final int LINK_ATTRIBUTE_CHANGED_EVENT    = 13;
	private static final int CONTACT_ATTRIBUTE_CHANGED_EVENT = 14;
	private static final int LINK_BUSY_EVENT                 = 15;
	private static final int EID_REACHABLE_EVENT             = 16;
	private static final int ROUTE_ADD_EVENT                 = 17;
	private static final int ROUTE_DELETE_EVENT              = 18;
	private static final int CUSTODY_SIGNAL_EVENT            = 19;
	private static final int CUSTODY_TIMEOUT_EVENT           = 20;
	private static final int INTENTIONAL_NAME_RESOLVED_EVENT = 21;
	private static final int REGISTRATION_ADDED_EVENT        = 22;
	private static final int REGISTRATION_REMOVED_EVENT      = 23;
	private static final int REGISTRATION_EXPIRED_EVENT      = 24;
	private static final int BUNDLE_REPORT                   = 25;
	private static final int LINK_REPORT                     = 26;
	private static final int LINK_ATTRIBUTES_REPORT          = 27;
	private static final int ROUTE_REPORT                    = 28;
	private static final int CONTACT_REPORT                  = 29;
	private static final int BUNDLE_ATTRIBUTES_REPORT        = 30;
	
	private static final String BPA_ELEMENT = "bpa";
	
	/**
	 * Constructor: Create stack that keeps track of current and
	 * parent elements. Define switch statement values for XML
	 * elements.
	 * 
	 * @param rtrHandlers Router interfaces for handling requests. 
	 */
	RAPID_SAX(Handlers rtrHandlers) {
		intf = rtrHandlers;
		elementStack = new Stack<XMLTree>();
		// Map element names to a value that we can switch off of
		// to call the appropriate handler.
		eventHash = new HashMap<String, Integer>();
		eventHash.put("bundle_received_event", BUNDLE_RECEIVED_EVENT);
		eventHash.put("data_transmitted_event", DATA_TRANSMITTED_EVENT);
		eventHash.put("bundle_delivered_event", BUNDLE_DELIVERED_EVENT);
		eventHash.put("bundle_delivery_event", BUNDLE_DELIVERY_EVENT);
		eventHash.put("bundle_send_cancelled_event", BUNDLE_SEND_CANCELLED_EVENT);
		eventHash.put("bundle_expired_event", BUNDLE_EXPIRED_EVENT);
		eventHash.put("bundle_injected_event", BUNDLE_INJECTED_EVENT);
		eventHash.put("link_opened_event", LINK_OPENED_EVENT);
		eventHash.put("link_closed_event", LINK_CLOSED_EVENT);
		eventHash.put("link_created_event", LINK_CREATED_EVENT);
		eventHash.put("link_deleted_event", LINK_DELETED_EVENT);
		eventHash.put("link_available_event", LINK_AVAILABLE_EVENT);
		eventHash.put("link_unavailable_event", LINK_UNAVAILABLE_EVENT);
		eventHash.put("link_attribute_changed_event", LINK_ATTRIBUTE_CHANGED_EVENT);
		eventHash.put("contact_attribute_changed_event", CONTACT_ATTRIBUTE_CHANGED_EVENT);
		eventHash.put("link_busy_event", LINK_BUSY_EVENT);
		eventHash.put("eid_reachable_event", EID_REACHABLE_EVENT);
		eventHash.put("route_add_event", ROUTE_ADD_EVENT);
		eventHash.put("route_delete_event", ROUTE_DELETE_EVENT);
		eventHash.put("custody_signal_event", CUSTODY_SIGNAL_EVENT);
		eventHash.put("custody_timeout_event", CUSTODY_TIMEOUT_EVENT);
		eventHash.put("intentional_name_resolved_event", INTENTIONAL_NAME_RESOLVED_EVENT);
		eventHash.put("registration_added_event", REGISTRATION_ADDED_EVENT);
		eventHash.put("registration_removed_event", REGISTRATION_REMOVED_EVENT);
		eventHash.put("registration_expired_event", REGISTRATION_EXPIRED_EVENT);
		eventHash.put("bundle_report", BUNDLE_REPORT);
		eventHash.put("link_report", LINK_REPORT);
		eventHash.put("route_report", ROUTE_REPORT);
	}

	/**
	 * Called when a new element is encountered by the parser. We always
	 * build the tree with the <bpa> element as its root. Ignore any parent
	 * elements of <bpa>.
	 *
	 * @param uri Will be empty.
	 * @param name Will be empty.
	 * @param qName The element's name.
	 * @param atts An array of key/value pairs made up of the element's
	 *        attributes.
	 */
	public void startElement (String uri, String name, String qName, Attributes atts) {
		if ((xmlRoot == null) && (!qName.equals(BPA_ELEMENT))) {
			return;
		}
		XMLTree el = new XMLTree(qName, atts);
		if (xmlRoot == null) {
			xmlRoot = el;
		} else {
			XMLTree parent = elementStack.peek();
			parent.addChildElement(el);
		}
		elementStack.push(el);
	}

	/**
	 * Called for characters between elements, e.g. <element>cccc</element>
	 * 
	 * @param ch Array of characters containing the data.
	 * @param start Index into ch[] of first character.
	 * @param length Count of characters.
	 */
	public void characters (char ch[], int start, int length) {
		String val = new String(ch, start, length).trim();
		if (val.length() == 0) {
			return;
		}
		elementStack.peek().assignValue(val);
	}
	
	/**
	 * Called when the end of an element is encountered by the parser.
	 * This method is called for tag pairs (<element>...</element>) and
	 * single elements (<element/>).
	 *
	 * @param uri Will be empty.
	 * @param name Will be empty.
	 * @param qName The element's name.
	 */
	public void endElement (String uri, String name, String qName) {
		if (xmlRoot == null) {
			// No <bpa> element yet.
			return;
		}
		elementStack.pop();
	}

	/**
	 * Called when the parser begins parsing the XML document.
	 */
	public void startDocument () {
		xmlRoot = null;
		elementStack.empty();
    }

	/**
	 * Called when we're done with the document. Invoke the appropriate
	 * router event handler method. Reset data structures to their initial
	 * states.
	 */
	public void endDocument () {
		if (xmlRoot != null) {
			int numElements = xmlRoot.numChildElements();
			if (numElements == 0) {
				rootOnly();
			} else {
				callRouter(numElements);
			}
		}
		xmlRoot = null;
		elementStack.empty();
    }

	/**
	 * Called when the parsed XML contains only a root element (<bpd>),
	 * which may contain attributes. 
	 */
	private void rootOnly() {
		intf.handler_bpa_root(xmlRoot);
	}
	
	/**
	 * Called when the root element (<bpa>) contains children elements.
	 * The router's methods are invoked to handle the children elements.
	 * 
	 * It *may* be more efficient to invoke the router when we get the
	 * close of each immediate BPA child element. But that's for if and
	 * when it is shown to be more efficient.
	 *  
	 * @param numElements Number of immediate children elements.
	 */
	private void callRouter(int numElements) {
		// We invoke the router method with the event element as the root (as
		// opposed to the <bpa> element). Assume 1 or more router events.
		for (int indx=0; indx<numElements; indx++) {
			XMLTree elementRoot = xmlRoot.getChildElement(indx);
			if (!eventHash.containsKey(elementRoot.getName())) {
				if (RAPID.log.enabled(Logging.ERROR)) {
					RAPID.log.error(
							"Received unsupported/unknown event from dtnd: " +
							elementRoot.getName());
				}
				continue;
			}
			try {
				switch (eventHash.get(elementRoot.getName())) {
					case BUNDLE_RECEIVED_EVENT:
						intf.handler_bundle_received_event(elementRoot, xmlRoot);
						break;
					case DATA_TRANSMITTED_EVENT:
						intf.handler_data_transmitted_event(elementRoot, xmlRoot);
						break;
					case BUNDLE_DELIVERED_EVENT:
						intf.handler_bundle_delivered_event(elementRoot, xmlRoot);
						break;
					case BUNDLE_DELIVERY_EVENT:
						intf.handler_bundle_delivery_event(elementRoot, xmlRoot);
						break;
					case BUNDLE_SEND_CANCELLED_EVENT:
						intf.handler_bundle_send_cancelled_event(elementRoot, xmlRoot);
						break;
					case BUNDLE_EXPIRED_EVENT:
						intf.handler_bundle_expired_event(elementRoot, xmlRoot);
						break;
					case BUNDLE_INJECTED_EVENT:
						intf.handler_bundle_injected_event(elementRoot, xmlRoot);
						break;
					case LINK_OPENED_EVENT:
						intf.handler_link_opened_event(elementRoot, xmlRoot);
						break;
					case LINK_CLOSED_EVENT:
						intf.handler_link_closed_event(elementRoot, xmlRoot);
						break;
					case LINK_CREATED_EVENT:
						intf.handler_link_created_event(elementRoot, xmlRoot);
						break;
					case LINK_DELETED_EVENT:
						intf.handler_link_deleted_event(elementRoot, xmlRoot);
						break;
					case LINK_AVAILABLE_EVENT:
						intf.handler_link_available_event(elementRoot, xmlRoot);
						break;
					case LINK_UNAVAILABLE_EVENT:
						intf.handler_link_unavailable_event(elementRoot, xmlRoot);
						break;
					case LINK_ATTRIBUTE_CHANGED_EVENT:
						intf.handler_link_attribute_changed_event(elementRoot, xmlRoot);
						break;
					case CONTACT_ATTRIBUTE_CHANGED_EVENT:
						intf.handler_contact_attribute_changed_event(elementRoot, xmlRoot);
						break;
					case LINK_BUSY_EVENT:
						intf.handler_link_busy_event(elementRoot, xmlRoot);
						break;
					case EID_REACHABLE_EVENT:
						intf.handler_eid_reachable_event(elementRoot, xmlRoot);
						break;
					case ROUTE_ADD_EVENT:
						intf.handler_route_add_event(elementRoot, xmlRoot);
						break;
					case ROUTE_DELETE_EVENT:
						intf.handler_route_delete_event(elementRoot, xmlRoot);
						break;
					case CUSTODY_SIGNAL_EVENT:
						intf.handler_custody_signal_event(elementRoot, xmlRoot);
						break;
					case CUSTODY_TIMEOUT_EVENT:
						intf.handler_custody_timeout_event(elementRoot, xmlRoot);
						break;
					case INTENTIONAL_NAME_RESOLVED_EVENT:
						intf.handler_intentional_name_resolved_event(elementRoot, xmlRoot);
						break;
					case REGISTRATION_ADDED_EVENT:
						intf.handler_registration_added_event(elementRoot, xmlRoot);
						break;
					case REGISTRATION_REMOVED_EVENT:
						intf.handler_registration_removed_event(elementRoot, xmlRoot);
						break;
					case REGISTRATION_EXPIRED_EVENT:
						intf.handler_registration_expired_event(elementRoot, xmlRoot);
						break;
					case BUNDLE_REPORT:
						intf.handler_bundle_report_event(elementRoot, xmlRoot);
						break;
					case LINK_REPORT:
						intf.handler_link_report_event(elementRoot, xmlRoot);
						break;
					case LINK_ATTRIBUTES_REPORT:
						intf.handler_link_attributes_report_event(elementRoot, xmlRoot);
						break;
					case ROUTE_REPORT:
						intf.handler_route_report_event(elementRoot, xmlRoot);
						break;
					case CONTACT_REPORT:
						intf.handler_contact_report_event(elementRoot, xmlRoot);
						break;
					case BUNDLE_ATTRIBUTES_REPORT:
						intf.handler_bundle_attributes_report_event(elementRoot, xmlRoot);
						break;
					default:
						if (RAPID.log.enabled(Logging.WARN)) {
							RAPID.log.warn(
									"Received unknown XML event from DTN server: " +
									elementRoot.getName());
						}
						break;
				}
			} catch (Exception e) {
				if (RAPID.log.enabled(Logging.ERROR)) {
					RAPID.log.error("Unhandled exception in message handler: " + e);
				}
			}
		}
	}
		
}
