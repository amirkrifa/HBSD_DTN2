/**
 * Manages all of the known nodes. A Node object is created per known node.
 * 
 * @author Brian Lynn <first initial last name at cs.umass.edu>
 * 
 * Copyright 2008 University of Massachusetts, Amherst
 * 
 * Licensed under the Apache License, Version 2.0 (the "License"); you may
 * not use this file except in compliance with the License. You may obtain
 * a copy of the License at
 *    http://www.apache.org/licenses/LICENSE-2.0
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * 
 * Funding for this project was provided by the Defense Advanced Research
 * Projects Agency (DARPA).
 * Distribution Statement A: Approved for public release; distribution
 * unlimited.
 */

import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.concurrent.locks.*;

class Nodes {
	
	protected Handlers router = null;
	
	private static final int DEFAULT_NODE_CAPACITY = 16;
	
	private ReentrantReadWriteLock nodesLock = null;
	private LinkedHashMap <String,Node> nodesList = null;
	
	/**
	 * Constructor. Initialize the table of known nodes.
	 */
	Nodes(Handlers router) {
		this.router = router;
		nodesLock = new ReentrantReadWriteLock();
		int nodeCapacity = 
			RAPID.routerConf.getInt("nodesHashCapacity", DEFAULT_NODE_CAPACITY);
		nodesList = new LinkedHashMap<String,Node>(nodeCapacity);
	}
	
	/**
	 * Add a node (EID), but only if it doesn't already exist in our tables.
	 * 
	 * Note: The assumption is that this method can be called from any thread.
	 * Though a Node object will often be created as a result of an event,
	 * e.g. a link being opened or a bundle being received, a Node object may
	 * be added whenever the router becomes aware of the node, e.g. as a
	 * result of meta data received by the policy manager.
	 * 
	 * @param eid EID to add.
	 * @return The instance of the Node class for the EID, regardless of
	 *    whether it already existed or we created it.
	 */
	Node conditionalAdd(String eid) {
		// Don't create a node for ourself.
		if (eid.equals(RAPID.localEID)) {
			return null;
		}
		// First check if it exists using the read lock. We may want to
		// revisit this if we typically call this without the EID already
		// existing, but this is probably the correct approach.
		nodesLock.readLock().lock();
		Node node = nodesList.get(eid);
		// Unlock regardless of whether we found it because we'll need the
		// write lock to create it and we can't upgrade locks.
		nodesLock.readLock().unlock();
		if (node != null) {
			// Found it.
			return node;
		}
		// Go ahead and create the Node object without the lock and then
		// acquire the write lock just to add it to the table.
		node = new Node(this, eid);
		boolean callPolicy = false;
		nodesLock.writeLock().lock();
		if (nodesList.containsKey(eid)) {
			// Make certain the node hadn't been created between releasing
			// the read lock and obtaining the write lock. If another thread
			// added the node while we didn't have the lock, use that object.
			node = nodesList.get(eid);
		} else {
			nodesList.put(eid, node);
			callPolicy = true;
		}
		nodesLock.writeLock().unlock();
		if (callPolicy) {
			router.policyMgr.nodeCreated(node);
			if (RAPID.log.enabled(Logging.DEBUG)) {
				RAPID.log.debug("Added node: " + eid);
			}
		}
		return node;
	}
	
	/**
	 * Locates the Node object for the specified EID.
	 * 
	 * @param eid EID to locate.
	 * @return The Node for the EID, else null if it does not exist.
	 */
	Node findNode(String eid) {
		nodesLock.readLock().lock();
		Node node = nodesList.get(eid);
		nodesLock.readLock().unlock();
		return node;
	}
	
	/**
	 * Determines if we have knowledge of a specific EID.
	 * 
	 * @param eid EID to verify.
	 * @return True if known, else false.
	 */
	boolean knowledgeOf(String eid) {
		return (findNode(eid) != null);
	}
	
	/**
	 * Queries for a list of all currently known nodes. Note that the list
	 * may become out of date as soon as we release the lock.
	 * 
	 * @return An array of all known nodes.
	 */
	Node [] allNodes() {
		nodesLock.readLock().lock();
		int numNodes = nodesList.size();
		Node nodeArray [] = new Node[numNodes];
		Iterator <Node> it = nodesList.values().iterator();
		int indx = 0;
		while (it.hasNext()) {
			nodeArray[indx++] = it.next();
		}
		nodesLock.readLock().unlock();
		return nodeArray;
	}
	
}
