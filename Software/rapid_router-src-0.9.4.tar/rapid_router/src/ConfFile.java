/**
 * ConfFile
 * 
 * Reads a configuration file creating a <key,value> mapping. Returns
 * values based on the key. This is purposely simplistic. If the first
 * non-whitespace is a hash character (#) then it's interpreted as a
 * comment. Otherwise, non-blank lines are expected to be key=value.
 * If the value contains blanks, it should be in either single or
 * double quotes.
 * 
 * @author Brian Lynn <first initial last name at cs.umass.edu>
 * 
 * Copyright 2008 University of Massachusetts, Amherst
 * 
 * Licensed under the Apache License, Version 2.0 (the "License"); you may
 * not use this file except in compliance with the License. You may obtain
 * a copy of the License at
 *    http://www.apache.org/licenses/LICENSE-2.0
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * 
 * Funding for this project was provided by the Defense Advanced Research
 * Projects Agency (DARPA).
 * Distribution Statement A: Approved for public release; distribution
 * unlimited.
 */

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.util.HashMap;

class ConfFile {
	
	private File confFile = null;
	private HashMap<String,String> map;
	
	/**
	 * Constructor: Called when there is no configuration file. A
	 * hash map is still created so that queries can be made on
	 * an empty hash table..
	 */
	ConfFile() {
		map = new HashMap<String, String>(1);
	}
	
	/**
	 * Constructor: Defines the configuration file.
	 *  
	 * @param fn File name.
	 */
	ConfFile(String fn) {
		confFile = new File(fn);
		map = new HashMap<String, String>();
	}
	
	/**
	 * Read the file and parse it.
	 * 
	 * @return Returns true if parsed, false if an error was encountered.
	 */
	boolean parse() {
		if (confFile == null) {
			return false;
		}
		if (!confFile.canRead()) {
			System.err.println(
					"Configuration file does not exist or cannot be read: "  
					+ confFile.getName());
			return false;
		}
		boolean stat = true;
		BufferedReader f = null;
		try {
			String line;
			f = new BufferedReader(new FileReader(confFile));
			// For each line in the file ...
			while ((line = f.readLine()) != null) {
				line = line.trim();
				if (line.length() == 0) {
					// Blank line.
					continue;
				}
				if (line.charAt(0) == '#') {
					// Comment line.
					continue;
				}
				int delim = line.indexOf('=');
				if (delim <= 0) {
					// No '=' found.
					System.err.println("Invalid line in configuration file: "
							+ line);
					stat = false;
					break;
				}
				String key = line.substring(0, delim).trim();
				// Value can be zero length.
				String val = "";
				if (++delim < line.length()) {
					val = line.substring(delim).trim();
					if (val.length() >= 2) {
						// Is value quoted?
						char cFirst = val.charAt(0);
						char cLast = val.charAt(val.length()-1);
						if (((cFirst == '\'') || (cFirst == '"')) && (cFirst == cLast)) {
							val = val.substring(1, val.length()-1);
						}
					}
				}
				// Everything is ok, store the key/value pair.
				map.put(key, val);
			}
		} catch(Exception e) {
			System.err.println("Exception processing configuration file: " +
					e.getMessage());
			stat = false;
		}
		try {
			f.close();
		} catch(Exception e) {
		}
		return stat;
	}
	
	/**
	 * Returns status of whether there is a readable configuration file.
	 * 
	 * @return True if file exists and is readable, else false.
	 */
	boolean haveFile() {
		if (confFile == null) {
			return false;
		}
		if (confFile.canRead()) {
			return true;
		}
		return false;
	}
	
	/**
	 * Query if a key is defined. Existence is independent of validity.
	 *
	 * @param key Key to look for.
	 * @return True if it is defined, otherwise false.
	 */
	boolean exists(String key) {
		return map.containsKey(key);
	}
	
	/**
	 * Return value as a string, boolean or integer. If key does not
	 * exist or cannot be formatted, return the specified default value.
	 * 
	 * @param key Key to search for
	 * @param dflt Default value to return if key not found.
	 * @return Value, or default.
	 */
	
	String getString(String key, String dflt) {
		String val = map.get(key);
		if (val == null) {
			return dflt;
		}
		return val;
	}
	
	boolean getBoolean(String key, boolean dflt) {
		String val = map.get(key);
		if (val == null) {
			return dflt;
		}
		return new Boolean(val).booleanValue();
	}
	
	int getInt(String key, int dflt) {
		String val = map.get(key);
		if (val == null) {
			return dflt;
		}
		try {
			Integer I = new Integer(Integer.parseInt(val));
			return I.intValue();
		} catch(Exception NumberFormatException) {
			return dflt;
		}
	}

}
