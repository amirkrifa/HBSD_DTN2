/**
 * Implementations of this interface are invoked by the Policy Manager.
 * The purpose of this interface is to allow for a system-aware interface
 * to deal with links. An implementation of this interface is not
 * required.
 * 
 * @author Brian Lynn <first initial last name at cs.umass.edu>
 * 
 * Copyright 2008 University of Massachusetts, Amherst
 * 
 * Licensed under the Apache License, Version 2.0 (the "License"); you may
 * not use this file except in compliance with the License. You may obtain
 * a copy of the License at
 *    http://www.apache.org/licenses/LICENSE-2.0
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * 
 * Funding for this project was provided by the Defense Advanced Research
 * Projects Agency (DARPA).
 * Distribution Statement A: Approved for public release; distribution
 * unlimited.
 */

interface LinkPolicyManager {
	
	/**
	 * Called to initialize the implementation of the LinkPolicyManager
	 * class.
	 * 
	 * @return True if initialization was successful, else false.
	 */
	boolean init();
	
	/**
	 * Called to determine whether a Link object should request DTN
	 * to open an non-open link. Typically a Node object requests
	 * that a link be opened by invoking a method in the link object.
	 * The Link object consults the Policy Manager. The Policy Manager
	 * may then invoke this method for advice.
	 * 
	 * @param link Link object representing the link in question.
	 * @param node Node object requesting that the link be opened.
	 * @return False if not to open, true if the router policy manager
	 *    should decide.
	 */
	boolean requestLinkOpen(Link link, Node node);
	
	/**
	 * Called when a link is created.
	 * 
	 * @param link Link object representing the created link.
	 */
	void linkCreated(Link link);
	
	/**
	 * Called when a link is deleted.
	 * 
	 * @param link Link object representing the deleted link.
	 */
	void linkDeleted(Link link);
	
	/**
	 * Called when a link is opened. This is called before notifying the
	 * link thread.
	 * 
	 * @param link Link object representing the opened link.
	 * @param node Node object associated with the link. Note that this may
	 *    be null.
	 */
	void linkOpened(Link link, Node node);
	
	/**
	 * Called when a link transitions from the open state. lThis is called
	 * after notifying the link thread.
	 * 
	 * @param link Link object representing the closed/unavailable link.
	 * @param node Node object associated with the link. Note that this may
	 *    be null.
	 */
	void linkNotOpen(Link link, Node node);

}
