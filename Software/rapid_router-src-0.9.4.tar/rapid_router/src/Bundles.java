/**
 * Manages the known bundles. All creations and deletions of a bundle should
 * be done through bundle manager interfaces. The exception are bundles
 * associated with router meta data. The bundle manager creates a Bundle object
 * for meta data bundles, but does not retain knowledge of the bundle.
 *
 * Note: All decisions to delete a bundle should be made by the policy
 * manager.
 * 
 * @author Brian Lynn <first initial last name at cs.umass.edu>
 * 
 * Copyright 2008 University of Massachusetts, Amherst
 * 
 * Licensed under the Apache License, Version 2.0 (the "License"); you may
 * not use this file except in compliance with the License. You may obtain
 * a copy of the License at
 *    http://www.apache.org/licenses/LICENSE-2.0
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * 
 * Funding for this project was provided by the Defense Advanced Research
 * Projects Agency (DARPA).
 * Distribution Statement A: Approved for public release; distribution
 * unlimited.
 */

import java.util.HashMap;
import java.util.NoSuchElementException;
import java.util.concurrent.locks.ReentrantReadWriteLock;

class Bundles {
	
	protected Handlers router = null;
	
	private static final int DEFAULT_ACTIVE_CAPACITY = 384;
	
	private HashMap <String,Bundle> activeBundles = null;
	private HashMap <Long,String> localidGBOFMap = null;
	
	private ReentrantReadWriteLock bundlesLock = null;
	
	/**
	 * Constructor.
	 * 
	 * @param The router object, i.e. RAPID_Routing.
	 */
	Bundles(Handlers router) {
		this.router = router;
		int hashCapacity = 
			RAPID.routerConf.getInt("bundlesActiveCapacity", DEFAULT_ACTIVE_CAPACITY);
		activeBundles = new HashMap<String,Bundle>(hashCapacity);
		localidGBOFMap = new HashMap<Long,String>(hashCapacity);
		bundlesLock = new ReentrantReadWriteLock();
	}
	
	/**
	 * Called when a bundle_report is received. Create a bundle from
	 * an element in the bundle report.
	 * 
	 * @param event XMLTree object of the <bundle> element within the
	 *    bundle_report.
	 * @return The created bundle object, or null if not created or it
	 *    previously existed.
	 */
	Bundle newBundleReported(XMLTree event) {
		Bundle bundle = new Bundle(this);
		long localId = bundle.initFromReport(event);
		if (localId < 0) {
			return null;
		}
		return addIfNew(bundle, localId);
	}
	
	/**
	 * Called to create a new bundle given a "bundle_received_event." The
	 * bundle is created, initialized, and added to the hash table.
	 * 
	 * @param evtBundleRcvd Root of bundle_received_event element.
	 * @return Created bundle; null if a bundle with this id already exists. 
	 */
	Bundle newBundle(XMLTree evtBundleRcvd) {
		// DTN will normally detect duplicate bundles and not deliver
		// a notification to us. But, still, we check.
		if (alreadyExists(evtBundleRcvd)) {
			if (RAPID.log.enabled(Logging.DEBUG)) {
				RAPID.log.debug("Dropping duplicate bundle");
			}
			return null;
		}
		// Create the instance of the Bundle object for the bundle.
		// Note that a local id of -1 is common: injected bundles
		// get created via a bundle_injected_event, then DTN sends
		// us the bundle_received_event for that same bundle.
		Bundle bundle = new Bundle(this);
		long localId = bundle.initReceived(evtBundleRcvd);
		if (localId == -1) {
			if (RAPID.log.enabled(Logging.DEBUG)) {
				RAPID.log.debug("Bundle likely meta-data from peer");
			}
			return null;
		}
		return addIfNew(bundle, localId);
	}
	
	/**
	 * Called to initialize a bundle that has been injected. Though we use a
	 * Bundle object, we do not keep track of it like we do other received
	 * bundles.
	 * 
	 * @param evtBundleInjected Root of the bundle_injected_event element.
	 * @return The created bundle.
	 */
	Bundle newInjectedBundle(XMLTree evtBundleInjected) {
		Bundle bundle = new Bundle(this);
		bundle.initGeneric(evtBundleInjected);
		bundle.injected = true;
		return bundle;
	}
	
	/**
	 * Called to initialize a new bundle that has been received and is
	 * intended for the router. We retain no knowledge of these bundles
	 * (though the policy manager may when it gets invoked).
	 */
	Bundle newBundleDelivery(XMLTree evtBundleDelivery) {
		Bundle bundle = new Bundle(this);
		long localId = bundle.initGeneric(evtBundleDelivery);
		if (localId == -1) {
			return null;
		}
		bundle.routingInfo = true;
		return bundle;
	}
	
	/**
	 * Determines if a bundle already exists. Obviously, this does not
	 * apply to injected bundles or bundles destined for the router.
	 * 
	 * @param evtBundleRcvd "bundle_received_event" XML message.
	 * @return True if it already exists, else false.
	 */
	private boolean alreadyExists(XMLTree evtBundleRcvd) {
		String key;
		try {
			XMLTree el = evtBundleRcvd.getChildElementRequired("gbof_id");
			key = GBOF.keyFromXML(el);
			if (key == null) {
				return true;
			}
		} catch (NoSuchElementException e) {
			if (RAPID.log.enabled(Logging.ERROR)) {
				RAPID.log.error("Ill-formed GBOF in received XML");
			}
			// Ill-formed: treat as a duplicate.
			return true;
		}
		boolean exists = false;
		bundlesLock.readLock().lock();
		exists = activeBundles.containsKey(key);
		bundlesLock.readLock().unlock();
		return exists;
	}
	
	/**
	 * Gets the bundle given its GBOF hash key.
	 * 
	 * @param gbofKey GBOF hash key.
	 * @return Bundle object if found, else null.
	 */
	Bundle getByKey(String gbofKey) {
		bundlesLock.readLock().lock();
		Bundle bundle = activeBundles.get(gbofKey);
		bundlesLock.readLock().unlock();
		return bundle;
	}
	
	/**
	 * Add the bundle to the active hash table if it doesn't already exist.
	 *  
	 * @param createdBundle The new bundle that is to be added.
	 * @param localId Bundle's local_id: the hash key.
	 * @return The created bundle, or null if already known.
	 */
	private Bundle addIfNew(Bundle createdBundle, long localId) {
		String gbof = GBOF.keyFromBundle(createdBundle);
		bundlesLock.writeLock().lock();
		if (localidGBOFMap.containsKey(localId)) {
			bundlesLock.writeLock().unlock();
			return null;
		}
		localidGBOFMap.put(localId, gbof);
		activeBundles.put(gbof, createdBundle);
		bundlesLock.writeLock().unlock();
		return createdBundle;
	}
	
	/**
	 * Called to expire a bundle. Remove knowledge of the bundle from our
	 * tables.
	 * 
	 * Note: The bundles are automatically removed from the data store by
	 * DTN so no additional interaction is required.
	 * 
	 * @param localId local_id of expired bundle.
	 * @return bundle Object representing the expired bundle.
	 */
	Bundle expire(long localId) {
		Bundle bundle = null;
		bundlesLock.writeLock().lock();
		String key = localidGBOFMap.remove(localId);
		if (key != null) {
			bundle = activeBundles.remove(key);
		}
		bundlesLock.writeLock().unlock();
		return bundle;
	}
	
		
	/**
	 * Called to remove a specific bundle. Removing involves losing
	 * knowledge of the bundle, but not sending a delete request to DTN.
	 * 
	 * @param bundle Bundle to be removed.
	 * @return True if the bundle had been active and therefore removed.
	 */
	private boolean remove(Bundle bundle) {
		boolean knowOf = false;
		bundlesLock.writeLock().lock();
		String gbof = localidGBOFMap.get(bundle.localId);
		if (gbof != null) {
			activeBundles.remove(gbof);
			knowOf = true;
		}
		bundlesLock.writeLock().unlock();
		return knowOf;
	}
	
	/**
	 * Called to delete a specific bundle. This causes a delete request
	 * to also be sent.
	 * 
	 * @param bundle Bundle to be deleted.
	 * @return True if the bundle had been active and therefore deleted.
	 */
	boolean delete(Bundle bundle) {
		boolean knowOf = remove(bundle);
		if (knowOf) {
			RAPID.requester.requestDeleteBundle(bundle);
		}
		return knowOf;
	}
	
	/**
	 * Called to delete a bundle. This differs from delete in that here a
	 * delete request is sent to DTN even if the bundle manager does not
	 * know about the bundle, such as with an injected bundle.
	 * 
	 * @param bundle The bundle that is to be deleted.
	 */
	void finished(Bundle bundle) {
		if (!bundle.injected) {
			remove(bundle);
		}
		RAPID.requester.requestDeleteBundle(bundle);
	}
	
	/**
	 * Determines if a bundle is current, which is simply its presence
	 * in the active map table. A bundle will be removed when it expires
	 * or at the discretion of the policy manager.
	 * 
	 * @param localId local_id to look for.
	 * @return True if current, else false.
	 */
	boolean isCurrent(long localId) {
		boolean current = false;
		bundlesLock.readLock().lock();
		String gbof = localidGBOFMap.get(localId);
		if (gbof != null) {
			if (activeBundles.containsKey(gbof)) {
				current = true;
			}
		}
		bundlesLock.readLock().unlock();
		return current;
	}
	
	/**
	 * Given a local id, return the bundle object.
	 * 
	 * @param localId Local id assigned by DTN to the bundle.
	 * @return Bundle object, or null if not found.
	 */
	Bundle bundlefromLocalId(long localId) {
		Bundle bundle = null;
		bundlesLock.readLock().lock();
		String gbof = localidGBOFMap.get(localId);
		if (gbof != null) {
			bundle = activeBundles.get(gbof);
		}
		bundlesLock.readLock().unlock();
		return bundle;
	}
	
	/**
	 * Called when a "bundle_expired_event" is received. Results in the
	 * bundle being removed from our hash of bundles. Note that links
	 * elsewhere may still reference the bundle.
	 *  
	 * @param evtBundleExpired XML element.
	 * @return bundle The expired bundle.
	 */
	Bundle eventExpired(XMLTree evtBundleExpired) {
		try {
			return expire(xmlLocalId(evtBundleExpired));
		} catch (NoSuchElementException e) {
			return null;
		}
	}
	
	/**
	 * Called when a "bundle_delivered_event" is received. Locates the
	 * corresponding bundle object.
	 *  
	 * @param evtBundleDelivered XML element.
	 * @return Bundle that was delivered. This can be null if the bundle is
	 *    a meta data bundle.
	 */
	Bundle eventDelivered(XMLTree evtBundleDelivered) {
		long localId;
		try {
			localId = xmlLocalId(evtBundleDelivered);
		} catch (NoSuchElementException e) {
			return null;
		}
		Bundle bundle = null;
		bundlesLock.readLock().lock();
		// The following lookup should fail for an injected bundle. But
		// we still check again later.
		String gbof = localidGBOFMap.get(localId);
		if (gbof != null) {
			bundle = activeBundles.get(gbof);
		}
		bundlesLock.readLock().unlock();
		if (bundle == null) {
			return null;
		}
		if (bundle.injected) {
			return null;
		}
		return bundle;
	}
	
	/**
	 * Extracts the local_id attribute from an XML element.
	 * 
	 * @param element XML element containing the attribute.
	 * @return The local_id as a long.
	 * @throws NoSuchElementException
	 */
	private long xmlLocalId(XMLTree element) throws NoSuchElementException {
		try {
			String id = element.getAttrRequired("local_id");
			long localId = new Long(id).longValue();
			return localId;
		} catch (Exception e) {
			throw new NoSuchElementException();
		}
	}

}
