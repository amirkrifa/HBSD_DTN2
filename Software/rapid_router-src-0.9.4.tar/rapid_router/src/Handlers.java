/**
 * Defines the router interfaces to be invoked by the SAX handler.
 * All events defined by the router.xsd schema should be represented
 * here as empty methods. 
 * 
 * @author Brian Lynn <first initial last name at cs.umass.edu>
 * 
 * Copyright 2008 University of Massachusetts, Amherst
 * 
 * Licensed under the Apache License, Version 2.0 (the "License"); you may
 * not use this file except in compliance with the License. You may obtain
 * a copy of the License at
 *    http://www.apache.org/licenses/LICENSE-2.0
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * 
 * Funding for this project was provided by the Defense Advanced Research
 * Projects Agency (DARPA).
 * Distribution Statement A: Approved for public release; distribution
 * unlimited.
 */

abstract class Handlers {
	
	// These are the principal objects that make up the RAPID router.
	protected Links links = null;
	protected Bundles bundles = null;
	protected Nodes nodes = null;
	protected Routes routes = null;
	protected PeerListener peerListener = null;
	
	// The following should be defined by the class that extends this class.
	// It refers to the instance of the routing Policy Manager, i.e. the
	// object that makes the routing decisions.
	protected Policy policyMgr = null;
	
	Handlers() {
		// Create instances of the classes that manage links, bundles, nodes
		// and routes.
		links = new Links(this);
		bundles = new Bundles(this);
		nodes = new Nodes(this);
		routes = new Routes(this);
		peerListener = new PeerListener(this);
	}
	
	// Called after RAPID is fully initialized, before starting its main loop.
	void initialized() {}

	// The class that extends this abstract class implements the handlers
	// that it supports. Unsupported events silently fall into these no-op
	// handlers.
	void handler_bpa_root(XMLTree bpa) {}
	void handler_bundle_received_event(XMLTree event, XMLTree bpa) {}
	void handler_data_transmitted_event(XMLTree event, XMLTree bpa) {}
	void handler_bundle_delivered_event(XMLTree event, XMLTree bpa) {}
	void handler_bundle_delivery_event(XMLTree event, XMLTree bpa) {}
	void handler_bundle_send_cancelled_event(XMLTree event, XMLTree bpa) {}
	void handler_bundle_expired_event(XMLTree event, XMLTree bpa) {}
	void handler_bundle_injected_event(XMLTree event, XMLTree bpa) {}
	void handler_link_opened_event(XMLTree event, XMLTree bpa) {}
	void handler_link_closed_event(XMLTree event, XMLTree bpa) {}
	void handler_link_created_event(XMLTree event, XMLTree bpa) {}
	void handler_link_deleted_event(XMLTree event, XMLTree bpa) {}
	void handler_link_available_event(XMLTree event, XMLTree bpa) {}
	void handler_link_unavailable_event(XMLTree event, XMLTree bpa) {}
	void handler_link_attribute_changed_event(XMLTree event, XMLTree bpa) {}
	void handler_contact_attribute_changed_event(XMLTree event, XMLTree bpa) {}
	void handler_link_busy_event(XMLTree event, XMLTree bpa) {}
	void handler_eid_reachable_event(XMLTree event, XMLTree bpa) {}
	void handler_route_add_event(XMLTree event, XMLTree bpa) {}
	void handler_route_delete_event(XMLTree event, XMLTree bpa) {}
	void handler_custody_signal_event(XMLTree event, XMLTree bpa) {}
	void handler_custody_timeout_event(XMLTree event, XMLTree bpa) {}
	void handler_intentional_name_resolved_event(XMLTree event, XMLTree bpa) {}
	void handler_registration_added_event(XMLTree event, XMLTree bpa) {}
	void handler_registration_removed_event(XMLTree event, XMLTree bpa) {}
	void handler_registration_expired_event(XMLTree event, XMLTree bpa) {}
	void handler_bundle_report_event(XMLTree event, XMLTree bpa) {}
	void handler_link_report_event(XMLTree event, XMLTree bpa) {}
	void handler_link_attributes_report_event(XMLTree event, XMLTree bpa) {}
	void handler_route_report_event(XMLTree event, XMLTree bpa) {}
	void handler_contact_report_event(XMLTree event, XMLTree bpa) {}
	void handler_bundle_attributes_report_event(XMLTree event, XMLTree bpa) {}
}
