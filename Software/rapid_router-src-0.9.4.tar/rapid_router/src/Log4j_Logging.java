/**
 * This is an implementation of the Logging class. It's simply a
 * wrapper around the Apache log4j 1.2 logger. Use of this logging
 * class requires the log4j jar. You can download the jar file
 * here: http://logging.apache.org/log4j/1.2/index.html. The log4j
 * logger provides more flexibility over the default console logger.
 * 
 * @author Brian Lynn <first initial last name at cs.umass.edu>
 * 
 * Copyright 2008 University of Massachusetts, Amherst
 * 
 * Licensed under the Apache License, Version 2.0 (the "License"); you may
 * not use this file except in compliance with the License. You may obtain
 * a copy of the License at
 *    http://www.apache.org/licenses/LICENSE-2.0
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * 
 * Funding for this project was provided by the Defense Advanced Research
 * Projects Agency (DARPA).
 * Distribution Statement A: Approved for public release; distribution
 * unlimited.
 */

import java.io.File;
import org.apache.log4j.BasicConfigurator;
import org.apache.log4j.ConsoleAppender;
import org.apache.log4j.Logger;
import org.apache.log4j.PatternLayout;
import org.apache.log4j.xml.DOMConfigurator;

class Log4j_Logging implements Logging {
	
	private static final String rapidLogClass = "RAPID";
	
	static final int DEFAULT = WARN;

	private static int currentLevel; 
	private static Logger log;
	
	Log4j_Logging() {
		log = Logger.getLogger(rapidLogClass);
	}
	
	/**
	 * Configure with logging going to the console, unless there is
	 * a default log4j.xml file lying around.
	 */
	public void conf() {
		if (!(new File("log4j.xml").canRead())) {
			ConsoleAppender appender = new ConsoleAppender(
					new PatternLayout("%d{HH:mm:ss.SSS} (%t) %p: %m%n"),
					ConsoleAppender.SYSTEM_OUT);
			BasicConfigurator.configure(appender);
		}
		initLevel();
	}
	
	/**
	 * Configure logging locations defined by the specified configuration
	 * file.
	 * 
	 * @param xmlConf Configuration file, XML defined by log4j.
	 */
	public void conf(String xmlConf) {
		// Catch a common error and default to the console. Otherwise if
		// configure() fails the user may see errors but we'll probably be
		// oblivious to them.
		if (!(new File(xmlConf).canRead())) {
			System.err.println(
					"Unable to access logj4 configuration file: " +
					xmlConf + 
					": logging to the console");
			conf();
			return;
		}
		DOMConfigurator.configure(xmlConf);
		initLevel();
	}
	
	/**
	 * A problem with this wrapper is it wants to know what the
	 * logging level is, in addition to log4j knowing. Here we
	 * synchronize our level with log4j's now that we've initialized
	 * log4j.
	 */
	private void initLevel() {
		int lev;
		try {
			lev = log.getEffectiveLevel().toInt();
		} catch (Exception e) {
			setLevel(DEFAULT);
			return;
		}
		switch (lev) {
			case org.apache.log4j.Level.ALL_INT:
				setLevel(ALL);
				break;
			case org.apache.log4j.Level.TRACE_INT:
				setLevel(TRACE);
				break;
			case org.apache.log4j.Level.DEBUG_INT:
				setLevel(DEBUG);
				break;
			case org.apache.log4j.Level.INFO_INT:
				setLevel(INFO);
				break;
			case org.apache.log4j.Level.WARN_INT:
				setLevel(WARN);
				break;
			case org.apache.log4j.Level.ERROR_INT:
				setLevel(ERROR);
				break;
			case org.apache.log4j.Level.FATAL_INT:
				setLevel(FATAL);
				break;
			case org.apache.log4j.Level.OFF_INT:
				setLevel(OFF);
				break;
			default:
				setLevel(DEFAULT);
		}
	}
	
	/**
	 * Sets the logging level.
	 * 
	 * @param lev New level.
	 */
	public void setLevel(int lev) {
		currentLevel = lev;
		switch (lev) {
			case ALL:
				log.setLevel(org.apache.log4j.Level.ALL);
				return;
			case TRACE:
				log.setLevel(org.apache.log4j.Level.TRACE);
				return;
			case DEBUG:
				log.setLevel(org.apache.log4j.Level.DEBUG);
				return;
			case INFO:
				log.setLevel(org.apache.log4j.Level.INFO);
				return;
			case WARN:
				log.setLevel(org.apache.log4j.Level.WARN);
				return;
			case ERROR:
				log.setLevel(org.apache.log4j.Level.ERROR);
				return;
			case FATAL:
				log.setLevel(org.apache.log4j.Level.FATAL);
				return;
			case OFF:
				log.setLevel(org.apache.log4j.Level.OFF);
				return;
			default:
				setLevel(DEFAULT);
		}
	}
	
	/**
	 * @return Returns the current logging level.
	 */
	public int getLevel() {
		return currentLevel;
	}
	
	/**
	 * Indicates whether logging is enabled for the given level.
	 * 
	 * @param lev Level to check.
	 * @return True if enabled, otherwise false.
	 */
	public boolean enabled(int lev) {
		return (currentLevel <= lev);
	}
		
	/**
	 * Logging write routines. All work the same: call logging if the logging
	 * level is appropriately set. The checks are redundant, but the real
	 * overhead is often in constructing the message. It's advised that
	 * enabled() be used prior to calling one of the following methods. 
	 */
	
	public void trace(String message) {
		if (currentLevel <= TRACE) {
			log.trace(message);
		}
	}
	
	public void debug(String message) {
		if (currentLevel <= DEBUG) {
			log.debug(message);
		}
	}
	
	public void info(String message) {
		if (currentLevel <= INFO) {
			log.info(message);
		}
	}
	
	public void warn(String message) {
		if (currentLevel <= WARN) {
			log.warn(message);
		}
	}
	
	public void error(String message) {
		if (currentLevel <= ERROR) {
			log.error(message);
		}
	}
	
	public void fatal(String message) {
		if (currentLevel <= FATAL) {
			log.fatal(message);
		}
	}
}
