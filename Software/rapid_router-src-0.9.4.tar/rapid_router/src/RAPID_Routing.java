/**
 * The class implementing the methods defined by Handlers abstract class.
 * The methods in this class are invoked by the XML parser when events
 * are received from the DTN daemon. All of the event handlers are
 * passed an XMLTree object that refers to the root of the event's
 * XML element.
 * 
 * @author Brian Lynn <first initial last name at cs.umass.edu>
 * 
 * Copyright 2008 University of Massachusetts, Amherst
 * 
 * Licensed under the Apache License, Version 2.0 (the "License"); you may
 * not use this file except in compliance with the License. You may obtain
 * a copy of the License at
 *    http://www.apache.org/licenses/LICENSE-2.0
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * 
 * Funding for this project was provided by the Defense Advanced Research
 * Projects Agency (DARPA).
 * Distribution Statement A: Approved for public release; distribution
 * unlimited.
 */

import java.util.NoSuchElementException;

class RAPID_Routing extends Handlers {
	
	private static final String BPA_ATTR_EID = "eid";
	private static final String defaultPolicy = "RAPID_Policy";
	
	/**
	 * Constructor: Let the abstract class create the primary objects. Get
	 * the name of the class implementing the Policy Manager and initialize
	 * it.
	 */
	RAPID_Routing() {
		super();
		// Load and initialize the router's policy manager.
		String routerPolicyClassName =
			RAPID.routerConf.getString("routerPolicyClass", defaultPolicy);
		try {
			super.policyMgr =
				(Policy) Class.forName(routerPolicyClassName).newInstance();
			if (!super.policyMgr.init(this)) {
				RAPID.log.fatal("Unable to initialize Policy Manager: " +
						routerPolicyClassName);
				System.exit(1);
			} 
		} catch (Exception e) {
			if (RAPID.log.enabled(Logging.ERROR)) {
				RAPID.log.error(
						"Unable to load the Policy Manager: " +
						e.getMessage());
			}
			System.exit(1);
		}
	}
	
	/**
	 * Called once RAPID is fully initialized.
	 */
	void initialized() {
		peerListener.init();
		// What we would like to do is get bundle, link and route reports so
		// that we can populate our tables if RAPID were to be started after
		// dtnd. Unfortunately, link reports don't provide the link_id so
		// their usefulness is questionable. Bundle reports are only partially
		// useful, since the local_id cannot be ascertained unless the bundle
		// was locally initiated. Regardless, we make our requests.
		RAPID.requester.queryLink();
		RAPID.requester.queryBundle();
		RAPID.requester.queryRoute();
	}
	
	/**
	 * Called when we first know that the DTN daemon is up. Sets the
	 * local EID found in the <bpa> element. 
	 * 
	 * @param bpa XML bpa element.
	 */
	private void firstMessage(XMLTree bpa) {
		if (RAPID.localEID != null) {
			return;
		}
		if (bpa.haveAttr(BPA_ATTR_EID)) {
			RAPID.setLocalEID(bpa.getAttr(BPA_ATTR_EID));
		} else {
			return;
		}
	}
	
	/**
	 * Called when there were no elements in the XML except the <bpa>
	 * element.
	 * 
	 * @param bpa XML bpa element.
	 */
	void handler_bpa_root(XMLTree bpa) {
		if (RAPID.localEID == null) {
			firstMessage(bpa);
		}
		if (bpa.haveAttr("alert")) {
			if ("shuttingDown".equals(bpa.getAttr("alert"))) {
				boolean verbose = RAPID.log.enabled(Logging.INFO);
				if (RAPID.routerConf.getBoolean("terminateWithDTN", true)) {
					if (verbose) {
						RAPID.log.info(
							"DTN daemon is terminating; RAPID will now terminate");
					}
					System.exit(0);
				}
				if (verbose) {
					RAPID.log.info(
						"DTN daemon is terminating; RAPID will continue to execute");
				}
			}
		}
	}
	
	/**
	 * Adds a bundles destination node to the list of known nodes if we
	 * were not previously aware of the node.
	 * 
	 * @param bundle The newly created bundle.
	 */
	private void addDestNode(Bundle bundle) {
		if (bundle.destEID != null) {
			if (!bundle.destEID.equals("")) {
				nodes.conditionalAdd(bundle.destEID);
			}
		}
	}
	
	/**
	 * Called when a bundle has been received by DTN. This can either be a
	 * locally generated bundle or one received from another node.
	 * 
	 * @param Root XML element of the event.
	 * @param The bpa element.
	 */
	void handler_bundle_received_event(XMLTree event, XMLTree bpa) {
		if (RAPID.localEID == null) {
			firstMessage(bpa);
		}
		// Create the new bundle.
		Bundle bundle = bundles.newBundle(event);
		if (bundle == null) {
			// We can get here if it's a special bundle for this router.
			return;
		}
		// Do we know about the bundle's destination node? if not, go
		// ahead and create a Node object for it. We specifically do
		// this before informing the policy manager of the bundle.
		addDestNode(bundle);
		policyMgr.bundleReceived(bundle);
	}
	
	/**
	 * Called when all or part of a bundle has been transmitted. Notify the
	 * link.
	 * 
	 * @param Root XML element of the event.
	 * @param The bpa element.
	 */
	void handler_data_transmitted_event(XMLTree event, XMLTree bpa) {
		if (RAPID.localEID == null) {
			firstMessage(bpa);
		}
		try {
			String linkId = event.getAttrRequired("link_id");
			Link link = links.getById(linkId);
			if (link == null) {
				if (RAPID.log.enabled(Logging.ERROR)) {
					RAPID.log.error(
							"Unable to locate link id to complete transmission: "
							+ linkId);
				}
				return;
			}
			link.dataTransmitted(
					new Long(event.getAttrRequired("local_id")).longValue(),
					new Integer(event.getAttrRequired("bytes_sent")).intValue(),
					new Integer(event.getAttrRequired("reliably_sent")).intValue());
		} catch (NoSuchElementException e) {
			
		}
	}
	
	/**
	 * Called when a bundle report is received. We request a report at start-up
	 * to learn what bundles exist if we are started after the DTN daemon.
	 * 
	 * @param Root XML element of the event.
	 * @param The bpa element.
	 */
	void handler_bundle_report_event(XMLTree event, XMLTree bpa) {
		if (RAPID.localEID == null) {
			firstMessage(bpa);
		}
		try {
			// For each bundle in the report, add the bundle.
			int num = event.numChildElements();
			for (int n=0; n<num; n++) {
				XMLTree evt = event.getChildElement(n);
				Bundle bundle = bundles.newBundleReported(evt);
				if (bundle == null) {
					continue;
				}
				addDestNode(bundle);
				policyMgr.bundleReceived(bundle);
			}
		} catch (Exception e) {
			if (RAPID.log.enabled(Logging.ERROR)) {
				RAPID.log.error("Ill-formed bundle_report received");
			}
		}
	}
	
	/**
	 * Called when a bundle was locally delivered. Let the bundle manager
	 * know.
	 * 
	 * @param Root XML element of the event.
	 * @param The bpa element.
	 */
	void handler_bundle_delivered_event(XMLTree event, XMLTree bpa) {
		if (RAPID.localEID == null) {
			firstMessage(bpa);
		}
		Bundle bundle = bundles.eventDelivered(event);
		if (bundle != null) {
			policyMgr.bundleDelivered(bundle);
		}
	}
	
	/**
	 * Called when a bundle is received whose destination endpoint indicates
	 * that the bundle is for an external router (such as this one). Invoke
	 * the peer listener thread.
	 * 
	 * @param Root XML element of the event.
	 * @param The bpa element.
	 */
	void handler_bundle_delivery_event(XMLTree event, XMLTree bpa) {
		if (RAPID.localEID == null) {
			firstMessage(bpa);
		}
		Bundle bundle = bundles.newBundleDelivery(event);
		if (bundle == null) {
			return;
		}
		// If we inject a meta data bundle we'll see it just as if had been
		// sent to us from another EID. If we are the source, ignore it.
		if (localSource(bundle)) {
			if (RAPID.log.enabled(Logging.DEBUG)) {
				RAPID.log.debug("Ignoring RAPID routing originated by this node");
			}
			return;
		}
		peerListener.eventDelivery(event, bundle);
	}
	
	/**
	 * Called when a bundle has expired. Let the bundle manager know.
	 * 
	 * @param Root XML element of the event.
	 * @param The bpa element.
	 */
	void handler_bundle_expired_event(XMLTree event, XMLTree bpa) {
		if (RAPID.localEID == null) {
			firstMessage(bpa);
		}
		Bundle bundle = bundles.eventExpired(event);
		if (bundle != null) {
			policyMgr.bundleExpired(bundle);
		}
	}

	/**
	 * Called when a bundle has been injected. This is in response to our
	 * request to inject a meta data bundle.
	 * 
	 * @param Root XML element of the event.
	 * @param The bpa element.
	 */
	void handler_bundle_injected_event(XMLTree event, XMLTree bpa) {
		if (RAPID.localEID == null) {
			firstMessage(bpa);
		}
		try {
			Bundle bundle = bundles.newInjectedBundle(event);
			if (bundle != null) {
				XMLTree el = event.getChildElementRequired("request_id");
				policyMgr.bundleInjected(bundle.localId, el.getValue(), bundle);
			}
		} catch (NoSuchElementException e) {
			RAPID.log.error("Error parsing injected bundle element");
		}
	}
	
	/**
	 * Called when a link has opened. Let the link know.
	 * 
	 * @param Root XML element of the event.
	 * @param The bpa element.
	 */
	void handler_link_opened_event(XMLTree event, XMLTree bpa) {
		if (RAPID.localEID == null) {
			firstMessage(bpa);
		}
		Link link = linkStructure(event);
		if (link != null) {
			link.opened(event);
		} else {
			RAPID.log.error("Opened unknown link");
		}
	}

	/**
	 * Called when a link has closed. Inform the link.
	 * 
	 * @param Root XML element of the event.
	 * @param The bpa element.
	 */
	void handler_link_closed_event(XMLTree event, XMLTree bpa) {
		if (RAPID.localEID == null) {
			firstMessage(bpa);
		}
		Link link = linkStructure(event);
		if (link != null) {
			link.closed(event);
		} else {
			RAPID.log.error("Closed unknown link");
		}
	}
	
	/**
	 * Called when a link has been created. Inform the link manager.
	 * 
	 * @param Root XML element of the event.
	 * @param The bpa element.
	 */
	void handler_link_created_event(XMLTree event, XMLTree bpa) {
		if (RAPID.localEID == null) {
			firstMessage(bpa);
		}
		links.create(event);
	}

	/**
	 * Called when a link has been deleted. Inform the link manager.
	 * 
	 * @param Root XML element of the event.
	 * @param The bpa element.
	 */
	void handler_link_deleted_event(XMLTree event, XMLTree bpa) {
		if (RAPID.localEID == null) {
			firstMessage(bpa);
		}
		links.delete(event);
	}

	/**
	 * Called when a link becomes available. Inform the link.
	 * 
	 * @param Root XML element of the event.
	 * @param The bpa element.
	 */
	void handler_link_available_event(XMLTree event, XMLTree bpa) {
		if (RAPID.localEID == null) {
			firstMessage(bpa);
		}
		Link link = linkStructure(event);
		if (link != null) {
			link.available(event);
		} else {
			if (RAPID.log.enabled(Logging.ERROR)) {
				RAPID.log.error("Unknown link became available");
			}
		}
	}

	/**
	 * Called when a link becomes unavailable. Let the link know.
	 * 
	 * @param Root XML element of the event.
	 * @param The bpa element.
	 */
	void handler_link_unavailable_event(XMLTree event, XMLTree bpa) {
		if (RAPID.localEID == null) {
			firstMessage(bpa);
		}
		Link link = linkStructure(event);
		if (link != null) {
			link.unavailable(event);
		} else {
			if (RAPID.log.enabled(Logging.ERROR)) {
				RAPID.log.error("Unknown link became unavailable");
			}
		}
	}

	/**
	 * Called when a link's attributes change. Let the link know.
	 * 
	 * @param Root XML element of the event.
	 * @param The bpa element.
	 */
	void handler_link_attribute_changed_event(XMLTree event, XMLTree bpa) {
		if (RAPID.localEID == null) {
			firstMessage(bpa);
		}
		Link link = linkStructure(event);
		if (link != null) {
			link.linkAttrsChanged(event);
		}
	}

	/**
	 * Called when a link's contact attributes change. Inform the link.
	 * 
	 * @param Root XML element of the event.
	 * @param The bpa element.
	 */
	void handler_contact_attribute_changed_event(XMLTree event, XMLTree bpa) {
		if (RAPID.localEID == null) {
			firstMessage(bpa);
		}
		Link link = linkStructure(event);
		if (link != null) {
			link.contactAttrsChanged(event);
		}
	}

	/**
	 * Called when a link becomes busy. Unfortunately, we aren't informed
	 * which link. Try to determine the link based on the remote EID then
	 * inform the link.
	 * 
	 * @param Root XML element of the event.
	 * @param The bpa element.
	 */
	void handler_link_busy_event(XMLTree event, XMLTree bpa) {
		if (RAPID.localEID == null) {
			firstMessage(bpa);
		}
		Link link = probableBusy(event);
		if (link != null) {
			link.busy(event);
		} else {
			if (RAPID.log.enabled(Logging.WARN)) {
				RAPID.log.warn("Unknown link became busy");
			}
		}
	}
	
	/**
	 * Called when a link_report is received.
	 * 
	 * @param Root XML element of the event.
	 * @param The bpa element.
	 */
	void handler_link_report_event(XMLTree event, XMLTree bpa) {
		if (RAPID.localEID == null) {
			firstMessage(bpa);
		}
		// Link reports are of no value because they do not include
		// the link_id. Therefore it's very much recommended that
		// this router be started before dtnd. We will take the
		// opportunity to tell the user that, since we should only
		// get a report if we're started after dtnd.
		if (RAPID.log.enabled(Logging.WARN)) {
			RAPID.log.warn(
					"RAPID router should be started before the DTN daemon");
		}
	}

	/**
	 * Called when a route is added. Tell the route manager.
	 * 
	 * @param Root XML element of the event.
	 * @param The bpa element.
	 */
	void handler_route_add_event(XMLTree event, XMLTree bpa) {
		if (RAPID.localEID == null) {
			firstMessage(bpa);
		}
		routes.addRoute(event);
	}

	/**
	 * Called when a link is deleted. Tell the route manager.
	 * 
	 * @param Root XML element of the event.
	 * @param The bpa element.
	 */
	void handler_route_delete_event(XMLTree event, XMLTree bpa) {
		if (RAPID.localEID == null) {
			firstMessage(bpa);
		}
		routes.deleteRoute(event);
	}
	
	/**
	 * Called when a route report is received. Inform the route manager.
	 * 
	 * @param Root XML element of the event.
	 * @param The bpa element.
	 */
	void handler_route_report_event(XMLTree event, XMLTree bpa) {
		if (RAPID.localEID == null) {
			firstMessage(bpa);
		}
		routes.reportReceived(event);
	}
		
	/**
	 * Determines if the source of the bundle is this node.
	 * 
	 * @param bundle Bundle being examined.
	 * @return True if from this node, else false.
	 */
	private boolean localSource(Bundle bundle) {
		try {
			String me = RAPID.localEID + "/";
			// Ignore endpoint.
			String sourceEID = bundle.sourceURI.substring(0, me.length());
			if (sourceEID.equals(me)) {
				return true;
			}
			return false;
		} catch (Exception e) {
			return false;
		}
	}
		
	/**
	 * Returns the value of the "link_id" attribute from the element
	 * represented by the XMLTree data structure.
	 * 
	 * @param el XML element.
	 * @return Id, or null if the attribute does not exist.
	 */
	private String linkId(XMLTree el) {
		if (el.haveAttr("link_id")) {
			return el.getAttr("link_id");
		}
		return null;
	}
	
	/**
	 * Returns the Link object associated with the XML element.
	 * 
	 * @param el XML element.
	 * @return Link object, of null if there is none for
	 *    this link id.
	 */
	private Link linkStructure(XMLTree el) {
		String id = linkId(el);
		if (id == null) {
			return null;
		}
		return links.getById(id);
	}
	
	/**
	 * Attempts to guess what link is busy given a "link_busy_event." This
	 * is required because the link_id is not part of the message.
	 * 
	 * @param event XML element.
	 * @return Link if found, else null.
	 */
	private Link probableBusy(XMLTree event) {
		try {
			XMLTree el = event.getChildElementRequired("link");
			String uri =
				el.getChildElementRequired("remote_eid").getAttrRequired("uri");
			return routes.getTemporalLink(GBOF.eidFromURI(uri), null, false);
		} catch (NoSuchElementException e) {
			return null;
		}
	}
		
}
