/**
 * This class is used to send messages to the DTN daemon. We try to limit the
 * construction and sending of request XML messages to within this class 
 * 
 * @author Brian Lynn <first initial last name at cs.umass.edu>
 * 
 * Copyright 2008 University of Massachusetts, Amherst
 * 
 * Licensed under the Apache License, Version 2.0 (the "License"); you may
 * not use this file except in compliance with the License. You may obtain
 * a copy of the License at
 *    http://www.apache.org/licenses/LICENSE-2.0
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * 
 * Funding for this project was provided by the Defense Advanced Research
 * Projects Agency (DARPA).
 * Distribution Statement A: Approved for public release; distribution
 * unlimited.
 */

import java.net.*;
import java.util.concurrent.atomic.*;

class Requester {
	
	static final int FWD_ACTION_FORWARD = 0;
	static final int FWD_ACTION_COPY = 1;
	
	private static final String xmlBanner = "<?xml version=\"1.0\" encoding=\"UTF-8\"?>";
	private static final String BPA_END = "\n</bpa>";
	private String bpaStart = null;
	private String xmlWithBpaStart = null;

	private static final String LOOPBACKADR = "127.0.0.1";
	private int defaultDestPort = 0;
	private InetAddress defaultDestAddr = null;
	private DatagramSocket socket = null;
	
	protected int sourcePort = 0;
	
	private AtomicInteger injectIdSeq;
	private String idBase;
	
	/**
	 * Constructor: Initialize values used to generate a unique id when
	 * injecting a bundle.
	 */
	Requester() {
		idBase = this.hashCode() + "-" + System.currentTimeMillis() + "-";
		injectIdSeq = new AtomicInteger(1);
	}
	
	/**
	 * Creates a multicast/datagram socket that will be used to send requests
	 * to the dtnd multicast socket.
	 * 
	 * Whether or not we use a multicast or UDP datagram socket depends on a 
	 * configuration value. We've had issues with using datagram sockets on
	 * at least on platform, and issues with the multicast TTL not being
	 * honored on another platform. Pick the solution that works for you.
	 * (See the example RAPID configuration file for more details.) 
	 * 
	 * @param group Multicast group for sending requests.
	 * @param port Destination port.
	 * @throws Exception Throws exceptions caught when creating the socket.
	 */
	void init(String group, int port) throws Exception {
		try {
			defaultDestPort = port;
			defaultDestAddr = InetAddress.getByName(group);
			boolean useMulticastSocket =
				RAPID.routerConf.getBoolean("multicastSends", false);
			if (useMulticastSocket) {
				socket = new MulticastSocket();
				((MulticastSocket)socket).joinGroup(defaultDestAddr);
				try {
					// Limit sends to this node only.
					((MulticastSocket)socket).setTimeToLive(0);
				} catch (Exception ex) {
					RAPID.log.warn("Failed to set multicast TTL value: " +
							ex.getMessage());
				}
			} else {
				String adr =
					RAPID.routerConf.getString("loopbackAddress", LOOPBACKADR);
				socket = new DatagramSocket(0, InetAddress.getByName(adr));
			}
			sourcePort = socket.getLocalPort();
		} catch (Exception e) {
			throw e;
		}
	}
	
	/**
	 * Utility function to construct, save and re-use what is repeatedly
	 * used in XML requests.
	 */
	synchronized private void constructStarts() {
		if (bpaStart == null) {
			bpaStart = "<bpa eid=\"" + RAPID.localEID + "\">";
		}
		if (xmlWithBpaStart == null) {
			if (RAPID.log.enabled(Logging.TRACE)) {
				// Add some whitespace if logging simply to make it easier
				// to read.
				xmlWithBpaStart = xmlBanner + "\n" + bpaStart + "\n  ";
			} else {
				xmlWithBpaStart = xmlBanner + bpaStart;
			}
		}
	}
	
	/**
	 * Gets the commonly used start of a request:
	 *   <?xml ...><bpa eid=...>
	 *   
	 * @return String containing the start of the XML plus the start of the
	 *    bpa element.
	 */
	private String getMsgStart() {
		if (RAPID.localEID == null) {
			// Local EID not yet known: don't cache value yet.
			String tmpXML = xmlBanner + "\n<bpa eid=\"null\">\n  ";
			return tmpXML;
		}
		if (xmlWithBpaStart == null) {
			constructStarts();
		}
		return xmlWithBpaStart;
	}
	
	/**
	 * Encapsulate the XML element into a full XML message and send it to
	 * the supplied port.
	 * 
	 * @param data XML element.
	 * @param port Destination datagram port.
	 * @return True on success, false on failure.
	 */
	private boolean xmlEncapsulateAndSend(final String data, InetAddress addr,
			int port) {
		try {
			String strMsg = getMsgStart() + data + BPA_END;
			byte [] msg = strMsg.getBytes();
			DatagramPacket packet = new DatagramPacket(msg, msg.length, addr, port);
			if (RAPID.log.enabled(Logging.TRACE)) {
				RAPID.log.trace(strMsg);
			}
			socket.send(packet);
			return true;
		} catch (Exception e) {
			if (RAPID.log.enabled(Logging.ERROR)) {
				RAPID.log.error("Failed to send request to dtnd: " + e.getMessage());
			}
			return false;
		}
	}
	
	/**
	 * Send XML element on the default port.
	 * 
	 * @param data XML element to be sent.
	 * @return True on success, false on failure.
	 */
	boolean sendAsXML(final String data) {
		return xmlEncapsulateAndSend(data, defaultDestAddr, defaultDestPort);
	}

	
	/**
	 * Send request to open a link.
	 * 
	 * @param linkId Id of the link to be opened.
	 * @return Status of the request.
	 */
	boolean requestOpenLink(String linkId) {
		String req = "<open_link_request link_id=\"" + linkId + "\"/>";
		return sendAsXML(req);
	}
	
	/**
	 * Send request to close a link.
	 * 
	 * @param linkId Id of the link to be closed.
	 * @return Status of the request.
	 */
	boolean requestCloseLink(String linkId) {
		String req = "<close_link_request link_id=\"" + linkId + "\"/>";
		return sendAsXML(req);
	}
	
	/**
	 * Send request to add a link.
	 * 
	 * Note: DTN has bugs that prevents an add_link_request from working as
	 * of DTN 2.5. These have been reported by others. This method does
	 * nothing and the use of the functionality is not supported.
	 * 
	 * @param linkId Id of the link to be created.
	 * @param clayer Connection layer, e.g. "tcp".
	 * @param type Link type, e.g. "opportunistic."
	 * @param isUsable True if the link is usable.
	 * @param reactiveFrag True if the link supports reactive fragmentation.
	 * @param nextHop The next hop, e.g. an IP address.
	 * @param minRetryInterval Minimum seconds before retrying.
	 * @param maxRetryInterval Maximum seconds before retrying.
	 * @param idleCLoseTime Seconds before closing an idle link.
	 * @param remoteEID The remote EID, e.g. "dtn:none."
	 * @return Status of the request.
	 */
	boolean requestAddLink(final String linkId, final String clayer,
			final String type,	boolean isUsable, boolean reactiveFrag,
			final String nextHop, int minRetryInterval,int  maxRetryInterval,
			int idleCloseTime, final String remoteEID) {
		return false;
	}
	
	/**
	 * Send request to delete a link.
	 * 
	 * @param linkId Id of the link to be delete.
	 * @return Status of the request.
	 */
	boolean requestDeleteLink(final String linkId) {
		String req = "<delete_link_request link_id=\"" + linkId + "\"/>";
		return sendAsXML(req);
	}
	
	/**
	 * Generate a request to send a bundle.
	 * 
	 * @param bundle Bundle object representing the bundle to be sent.
	 * @param linkId Id of link bundle is to be sent on.
	 * @param action Forwarding action for the bundle.
	 * @return Indicates success or failure of the request.
	 */
	boolean requestSendBundle(Bundle bundle, final String linkId, int action) {
		String req = "<send_bundle_request local_id=\"" + bundle.localId +
				"\" link_id=\"" + linkId + "\" fwd_action=\"";
		if (action == FWD_ACTION_FORWARD) {
			req += "forward\">";
		} else {
			req += "copy\">";
		}
		req += GBOF.xmlFromBundle(bundle) + "</send_bundle_request>";
		return sendAsXML(req);
	}
	
	/**
	 * Called to request that a bundle be injected. 
	 * 
	 * @param source Source EID.
	 * @param dest Destination EID.
	 * @param linkId Id of the link the bundle will be sent on.
	 * @param payloadFile File containing the payload data.
	 * @return Returns the ID associated with the injected bundle.
	 */
	String requestInjectBundle(final String source, final String dest,
			final String linkId, final String payloadFile) {
		// Generate an id that will uniquely identify the injected bundle.
		String requestId =  idBase + injectIdSeq.getAndDecrement();
		// Define the bundle to be forwarded with a hardcoded expiration.
		String req = "<inject_bundle_request request_id=\"" + requestId +
				"\" link_id=\"" + linkId + 
				"\" fwd_action=\"forward\" expiration=\"300\" payload_file=\"" +
				payloadFile + "\">"; 
		req += "<source uri=\"" + source + "\"/>";
		req += "<dest uri=\"" + dest + "\"/>";
		req += "</inject_bundle_request>";
		if (!sendAsXML(req)) {
			return null;
		}
		return requestId;
	}
	
	/**
	 * Generate a request to delete a bundle.
	 * 
	 * @param bundle Bundle object representing the bundle.
	 * @return Indicates success or failure of the request.
	 */
	boolean requestDeleteBundle(Bundle bundle) {
		String req = "<delete_bundle_request local_id=\"" + 
				bundle.localId + "\">" + 
				GBOF.xmlFromBundle(bundle) +
				"</delete_bundle_request>";
		return sendAsXML(req);
	}
	
	/**
	 * Generate a request to cancel a prior bundle transmission request.
	 * 
	 * @param bundle Bundle object representing the bundle.
	 * @return Indicates success or failure of the request.
	 */
	boolean requestCancelBundle(Bundle bundle, Link link) {
		String req = "<cancel_bundle_request local_id=\"" + 
				bundle.localId + "\" link_id=\"" + link.id + "\">" + 
				GBOF.xmlFromBundle(bundle) +
				"</cancel_bundle_request>";
		return sendAsXML(req);
	}
		
	/**
	 * Sends a bundle_query.
	 * 
	 * @return Whether or not we were able to send the query.
	 */
	boolean queryBundle() {
		return sendAsXML("<bundle_query/>");
	}
	
	/**
	 * Sends a link_query.
	 * 
	 * @return Whether or not we were able to send the query.
	 */
	public boolean queryLink() {
		return sendAsXML("<link_query/>");
	}
	
	/**
	 * Sends a route_query.
	 * 
	 * @return Whether or not we were able to send the query.
	 */
	public boolean queryRoute() {
		return sendAsXML("<route_query/>");
	}
}
