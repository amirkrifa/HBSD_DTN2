/**
 * Tree data structure used to hold SAX-parsed XML. Each instance of the
 * class represents an element. Each element is named and can contain an
 * optional value ("characters" from the SAX parser), 0 or more attributes
 * with their corresponding string values, and 0 or more sub-elements
 * (represented by a new instance of the XMLTree class linked to the parent
 * class).
 *    
 * @author Brian Lynn <first initial last name at cs.umass.edu>
 * 
 * Copyright 2008 University of Massachusetts, Amherst
 * 
 * Licensed under the Apache License, Version 2.0 (the "License"); you may
 * not use this file except in compliance with the License. You may obtain
 * a copy of the License at
 *    http://www.apache.org/licenses/LICENSE-2.0
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * 
 * Funding for this project was provided by the Defense Advanced Research
 * Projects Agency (DARPA).
 * Distribution Statement A: Approved for public release; distribution
 * unlimited.
 */

import java.util.HashMap;
import java.util.ArrayList;
import org.xml.sax.Attributes;
import java.util.NoSuchElementException;

class XMLTree {
	
	private String elementName = null;
	private String elementValue = null;
	private HashMap<String,String> elementAttributes = null;
	private ArrayList<XMLTree> childElements = null;

	/**
	 * Constructor used by our SAX parsing routines.
	 * 
	 * @param name Name of the element.
	 * @param attrs Attribute key/value pairs.
	 */
	XMLTree(String name, Attributes attrs) {
		elementName = name;
		elementAttributes = new HashMap<String, String>();
		for (int i=0; i<attrs.getLength(); i++) {
			elementAttributes.put(attrs.getQName(i), attrs.getValue(i));
		}
	}
	
	/**
	 * Constructor used elsewhere to build an XMLTree element.
	 * 
	 * @param name Name of the element.
	 * @param attrs Attribute key/value pairs.
	 */
	XMLTree(String name, HashMap<String,String> attrs) {
		elementName = name;
		elementAttributes = new HashMap<String,String>(attrs);
	}

	/**
	 * Returns the name of the element represented by the class.
	 */
	String getName() {
		return elementName;
	}

	/**
	 * Assign the element's value (<element>value</element>).
	 *
	 * @param val Value to assign.
	 */
	void assignValue(String val) {
		elementValue = val;
	}

	/**
	 * Returns whether or not the element has a character value.
	 *
	 * @return True if there is a value, false otherwise.
	 */
	boolean haveValue() {
		if (elementValue == null) {
			return false;
		}
		return true;
	}

	/**
	 * Returns the value.
	 * 
	 * @return The element's character value.
	 */
	String getValue() {
		return elementValue;
	}
	
	/**
	 * Queries whether the element has an attribute of the given name.
	 *
	 * @return True if the attribute exists, else false.
	 */
	boolean haveAttr(String key) {
		return elementAttributes.containsKey(key);
	}

	/**
	 * Gets the attribute value for the specified attribute.
	 *
	 * @return The attribute value, or null if no key.
	 */
	String getAttr(String key) {
		return elementAttributes.get(key);
	}
	
	/**
	 * Gets the attribute value for the specified attribute, throws an
	 * exception if the key does not exist.
	 * 
	 * @return The attribute value.
	 * @throws NoSuchElementException If the attribute does not exist.
	 */
	String getAttrRequired(String key) throws NoSuchElementException {
		String val = elementAttributes.get(key);
		if (val == null) {
			throw new NoSuchElementException("Invalid key");
		}
		return val;
	}
	
	/**
	 * Adds a child element to this element.
	 *
	 * @param element Child element.
	 */
	void addChildElement(XMLTree element) {
		if (childElements == null) {
			childElements = new ArrayList<XMLTree>();
		}
		childElements.add(element);
	}
	
	/**
	 * @return The number of direct children elements.
	 */
	int numChildElements() {
		if (childElements == null) {
			return 0;
		}
		return childElements.size();
	}

	/**
	 * Get a specific direct child element.
	 *
	 * @param x Index into array of direct children.
	 * @return Child represented by the index.
	 */
	XMLTree getChildElement(int x) {
		if (childElements == null) {
			return null;
		}
		if (x >= childElements.size()) {
			return null;
		}
		return childElements.get(x);
	}
	
	/**
	 * Searches for the first direct child element of the supplied name and
	 * returns the XMLTree object for the child. An exception is thrown if
	 * no matching child is found. 
	 * 
	 * @param name Name of element to search for.
	 * @return Child XMLTree object.
	 * @throws NoSuchElementException If no matching child found.
	 */
	XMLTree getChildElementRequired(String name) throws NoSuchElementException {
		int num = childElements.size();
		for (int x=0; x<num; x++) {
			XMLTree child = childElements.get(x);
			if (child.elementName.equals(name)) {
				return child;
			}
		}
		throw new NoSuchElementException("No such child element");
	}
	
}
