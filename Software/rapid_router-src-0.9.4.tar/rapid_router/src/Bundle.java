/**
 * This class describes a bundle. There should be an instance of the class
 * for each bundle on the system.
 * 
 * Note: A Bundle should not be created directly, but instead should be
 * created via newBundle() of the Bundles class.
 * 
 * @author Brian Lynn <first initial last name at cs.umass.edu>
 * 
 * Copyright 2008 University of Massachusetts, Amherst
 * 
 * Licensed under the Apache License, Version 2.0 (the "License"); you may
 * not use this file except in compliance with the License. You may obtain
 * a copy of the License at
 *    http://www.apache.org/licenses/LICENSE-2.0
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * 
 * Funding for this project was provided by the Defense Advanced Research
 * Projects Agency (DARPA).
 * Distribution Statement A: Approved for public release; distribution
 * unlimited.
 */

import java.util.NoSuchElementException;

class Bundle {
	
	// Point to the instance of the Bundles class, which manages
	// all bundles, and the creator of this Bundle class's instance.
	// We call into the manager for things such as determining if
	// the bundle represented by this instance is still relevant.
	private Bundles bundleManager = null;
	
	protected Object policyInfo = null;
	
	// Values set when created. These can be read by others.
	boolean routingInfo = false;
	boolean injected = false;
	long localId = -1;
	int bytesReceived = 0;
	int numMetaBlocks = 0;
	long expiration = 0;
	long creationTimestamp = 0;
	long creationSeconds = 0;
	long expiresAtMillis = 0; // Not set for injected & delivery bundles!
	String sourceURI = null;
	String sourceEID = null;
	int fragLength = 0;
	int fragOffset = 0;
	boolean isFragment = false;
	String destURI = null;
	String destEID = null;
	String custodianURI = null;
	String replyToURI = null;
	String prevHopURI = null;
	String gbofKey = null;
	
	/**
	 * Constructor: sets the Bundles class that maintains knowledge of
	 * all bundles.
	 * 
	 * @param manager Bundles class that is creating this bundle.
	 */
	Bundle(Bundles manager) {
		bundleManager = manager;
	}
		
	/**
	 * Called to initialize the Bundle object. Parses the
	 * "bundle_received_event" XML data.
	 * 
	 * Note: This method should only be called by the Bundles class.
	 * 
	 * @param evtBundleRcvd Root of the bundle_received_event.
	 * @return The bundle's local_id, or -1 if an error was encountered or
	 *    the bundle is a special bundle destined for this router.
	 */
	protected long initReceived(XMLTree evtBundleRcvd) {
		try {
			// This bundle was received, not injected.
			// Get mandatory attributes. Convert them to their integer/long
			// value. (Java doesn't support unsigned ints so we may use longs to
			// store some of the unsigned values.)
			String strLocalId = evtBundleRcvd.getAttrRequired("local_id");
			localId = new Long(strLocalId).longValue();
			String strExpiration = evtBundleRcvd.getAttrRequired("expiration");
			expiration = new Long(strExpiration).longValue();
			String strBytesReceived = evtBundleRcvd.getAttrRequired("bytes_received");
			bytesReceived = new Integer(strBytesReceived).intValue();
			// Optional attributes.
			if (evtBundleRcvd.haveAttr("num_meta_blocks")) {
				String strNumMetaBlocks = evtBundleRcvd.getAttr("num_meta_blocks");
				numMetaBlocks = new Integer(strNumMetaBlocks).intValue();
			}
			// Now parse the child elements.
			int nElements = evtBundleRcvd.numChildElements();
			for (int x=0; x<nElements; x++) {
				XMLTree el = evtBundleRcvd.getChildElement(x);
				if (el.getName().equals("gbof_id")) {
					parseGBOF(el);
				} else if (el.getName().equals("dest")) {
					destURI = el.getAttrRequired("uri");
					destEID = GBOF.eidFromURI(destURI);
				} else if (el.getName().equals("custodian")) {
					custodianURI = el.getAttrRequired("uri");
				} else if (el.getName().equals("replyto")) {
					replyToURI = el.getAttrRequired("uri");
				} else if (el.getName().equals("prevhop")) {
					prevHopURI = el.getAttrRequired("uri");
				}
			}
		} catch (NoSuchElementException e) {
			return -1;
		} catch (Exception e) {
			if (RAPID.log.enabled(Logging.ERROR)) {
				RAPID.log.error(
						"Unanticipated exception initializing Bundle object: " +
						e.getMessage());
			}
			return -1;
		}
		// Special case: the bundle is destined for this router. If that is the
		// case then we should have already received a bundle_delivery_event for
		// this bundle. So, after all that work, forget about it.
		if (destURI.equals(RAPID.rapidRegistration)) {
			return -1;
		}
		expiresAtMillis = GBOF.calculateExpiration(creationTimestamp, expiration);
		if (RAPID.log.enabled(Logging.DEBUG)) {
			long xx = (expiresAtMillis - System.currentTimeMillis()) / 1000;
			RAPID.log.debug("Created Bundle object:" + 
					" localId=" + localId +
					" expiration=" + expiration + " (" + xx + " seconds)" +
					" sourceURI=" + sourceURI + 
					" destURI=" + destURI);
		}
		return localId;
	}
	
	/**
	 * Called to initialize a bundle based on a bundle element within a
	 * bundle_report;
	 * 
	 * @param event The bundle element.
	 * @return The local ID if successful, else -1.
	 */
	protected long initFromReport(XMLTree event) {
		try {
			// Create the bundle from the information in the report. The global
			// creation timestamp and local Id need to be derived from the creation
			// seconds and sequence Ids.
			long localSeq = new Long(event.getAttrRequired("bundleid"));
			long globalSeq = new Long(event.getAttrRequired("creation_ts_seqno"));
			long creationSecs = new Long(event.getAttrRequired("creation_ts_seconds"));
			localId = creationSecs << 32 | localSeq;
			creationTimestamp = creationSecs << 32 | globalSeq;
			creationSeconds = GBOF.creationSeconds(creationTimestamp);
			expiration = new Long(event.getAttrRequired("expiration")).longValue();
			expiresAtMillis = GBOF.calculateExpiration(creationTimestamp, expiration);
			fragLength = new Integer(event.getAttrRequired("orig_length")).intValue();
			fragOffset = new Integer(event.getAttrRequired("frag_offset")).intValue();
			isFragment = new Boolean(event.getAttrRequired("is_fragment")).booleanValue();
			int nElements = event.numChildElements();
			for (int x=0; x<nElements; x++) {
				XMLTree el = event.getChildElement(x);
				if (el.getName().equals("gbof_id")) {
					parseGBOF(el);
				} else if (el.getName().equals("dest")) {
					destURI = el.getAttrRequired("uri");
					if (destURI.equals(RAPID.rapidRegistration)) {
						// Old registration meta-data bundle.
						return -1;
					}
					destEID = GBOF.eidFromURI(destURI);
				} else if (el.getName().equals("custodian")) {
					custodianURI = el.getAttrRequired("uri");
				} else if (el.getName().equals("replyto")) {
					replyToURI = el.getAttrRequired("uri");
				} else if (el.getName().equals("prevhop")) {
					prevHopURI = el.getAttrRequired("uri");
				} else if (el.getName().equals("source")) {
					sourceURI = el.getAttrRequired("uri");
					sourceEID = GBOF.eidFromURI(sourceURI);
				}
			}
			sourceEID = GBOF.eidFromURI(sourceURI);
			// Well, after all of that work we decide if we want to discard
			// this bundle. That's because the local_id is bogus if the
			// bundle was not locally created. It seems that the local_id uses
			// the timestamp from when this node received the bundle, as opposed
			// to the global creation timestamp.
			if (!sourceEID.equals(RAPID.localEID)) {
				if (RAPID.log.enabled(Logging.DEBUG)) {
					RAPID.log.debug(
							"Bundle in report ignored (not locally created): "
							+ creationTimestamp);
				}
				return -1;
			}
			gbofKey = GBOF.keyFromBundleObject(this);
			if (RAPID.log.enabled(Logging.DEBUG)) {
				long xx = (expiresAtMillis - System.currentTimeMillis()) / 1000;
				RAPID.log.debug("Created Bundle object from report:" + 
						" localId=" + localId + 
						" expiration=" + expiration + " (" + xx + " seconds)" +
						" sourceURI=" + sourceURI + 
						" destURI=" + destURI);
			}
			return localId;
		} catch (NoSuchElementException e) {
			return -1;
		}
	}
	
	/**
	 * Called to initialize the Bundle object when a "generic"
	 * event is received. Generic means that the event contains a
	 * local_id attribute and has a gbof_id child element. This is
	 * typically used for events such as "bundle_injected_event" and
	 * "bundle_delivery_event".
	 * 
	 * Note: This method should only be called by the Bundles class.
	 * 
	 * @param event XML root.
	 * @return The bundle's local_id, or -1 if an error was encountered.
	 */
	protected long initGeneric(XMLTree event) {
		try {
			// Get the local id of the bundle.
			String strLocalId = event.getAttrRequired("local_id");
			localId = new Long(strLocalId).longValue();
			// Now parse the GBOF.
			XMLTree el = event.getChildElementRequired("gbof_id");
			parseGBOF(el);
			return localId;
		} catch (NoSuchElementException e) {
			return -1;
		} catch (Exception e) {
			if (RAPID.log.enabled(Logging.ERROR)) {
				RAPID.log.error(
						"Unanticipated exception initializing Bundle object: " +
						e.getMessage());
			}
			return -1;
		}
	}
	
	/**
	 * Parses the "gbof_id" element. Stores the information in variables
	 * global to this object.
	 * 
	 * @param element Root of the gbof_id element.
	 * @throws NoSuchElementException via XMLTree access routines.
	 */
	private void parseGBOF(XMLTree element) throws NoSuchElementException {
		creationTimestamp = new Long(element.getAttrRequired("creation_ts")).longValue();
		creationSeconds = GBOF.creationSeconds(creationTimestamp);
		fragLength = new Integer(element.getAttrRequired("frag_length")).intValue();
		fragOffset = new Integer(element.getAttrRequired("frag_offset")).intValue();
		isFragment = new Boolean(element.getAttrRequired("is_fragment")).booleanValue();
		XMLTree el = element.getChildElementRequired("source");
		sourceURI = el.getAttrRequired("uri");
		sourceEID = GBOF.eidFromURI(sourceURI);
		gbofKey = GBOF.keyFromBundleObject(this);
	}
	
	/**
	 * Called to determine if the bundle is current, i.e. not expired and
	 * not delivered. We query the bundle manager for this information.
	 * 
	 * @return True if current, else false.
	 */
	boolean isCurrent() {
		return bundleManager.isCurrent(localId);
	}
	
	/**
	 * Called to delete this bundle. Invoke the bundle manager to do the
	 * actual work.
	 * 
	 * Note: This should normally be called by the policy manager.
	 */
	void delete() {
		bundleManager.delete(this);
	}
			
	/**
	 * Called to delete a bundle. This differs from delete in that here a
	 * delete request is sent to DTN even if the bundle manager does not
	 * know about the bundle, such as with an injected bundle.
	 */
	void finished() {
		bundleManager.finished(this);
	}
	
}
