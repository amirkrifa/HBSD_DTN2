/**
 * Simple implementation of the Logging class that sends log messages
 * to the console. This is provided to allow logging without log4j.
 * 
 * This is now the default logger. To explicitly enable, add
 * 
 *    loggingClass=Console_Logging
 *    
 * to the RAPID configuration file.
 * 
 * @author Brian Lynn <first initial last name at cs.umass.edu>
 * 
 * Copyright 2008 University of Massachusetts, Amherst
 * 
 * Licensed under the Apache License, Version 2.0 (the "License"); you may
 * not use this file except in compliance with the License. You may obtain
 * a copy of the License at
 *    http://www.apache.org/licenses/LICENSE-2.0
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * 
 * Funding for this project was provided by the Defense Advanced Research
 * Projects Agency (DARPA).
 * Distribution Statement A: Approved for public release; distribution
 * unlimited.
 */

import java.text.SimpleDateFormat;
import java.util.Date;

class Console_Logging implements Logging {
	
	static final int DEFAULT = WARN;
	private static int currentLevel = DEFAULT;
	private SimpleDateFormat dateFormat;
	
	/**
	 * Constructor: define how the time stamp is to be displayed.
	 */
	Console_Logging() {
		dateFormat = new SimpleDateFormat("HH:mm:ss.SSS");
	}
	
	/**
	 * Nothing to configure.
	 */
	public void conf() {
		
	}
	
	/**
	 * Still nothing to configure, but the Logging interface insists that
	 * we accept a configuration file.
	 */
	public void conf(String confFile) {
		
	}
	
	/**
	 * Sets the logging level.
	 * 
	 * @param lev New level.
	 */
	public void setLevel(int lev) {
		currentLevel = lev;
	}
	
	/**
	 * @return Returns the current logging level.
	 */
	public int getLevel() {
		return currentLevel;
	}
	
	/**
	 * Indicates whether logging is enabled for the given level.
	 * 
	 * @param lev Level to check.
	 * @return True if enabled, otherwise false.
	 */
	public boolean enabled(int lev) {
		return (currentLevel <= lev);
	}
		
	/**
	 * Logging write routines.
	 * 
	 * @param message Message to be logged.
	 */
	
	public void trace(String message) {
		if (currentLevel <= TRACE) {
			output(message, "TRACE");
		}
	}
	
	public void debug(String message) {
		if (currentLevel <= DEBUG) {
			output(message, "DEBUG");
		}
	}
	
	public void info(String message) {
		if (currentLevel <= INFO) {
			output(message, "INFO");
		}
	}
	
	public void warn(String message) {
		if (currentLevel <= WARN) {
			output(message, "WARN");
		}
	}
	
	public void error(String message) {
		if (currentLevel <= ERROR) {
			output(message, "ERROR");
		}
	}
	
	public void fatal(String message) {
		if (currentLevel <= FATAL) {
			output(message, "FATAL");
		}
	}
	
	/**
	 * Outputs a string to stdout along with a time stamp and the name of
	 * the calling thread.
	 * 
	 * @param message String to be printed.
	 * @param level Logging level of the message.
	 */
	private void output(String message, String level) {
		System.out.print(dateFormat.format(new Date()) + 
				" (" + Thread.currentThread().getName() + ") "
				+ level + ": ");
		System.out.println(message);
	}

}
