/**
 * RAPID
 * 
 * This is the main body of the RAPID router.
 * 
 * 1) Get any command line options passed to this program.
 * 2) Read options from the configuration file, if any.
 * 3) Set up the SAX XML parser.
 * 4) Create a multicast socket for receiving data from dtnd.
 * 5) Loop forever receiving messages on the socket and taking the
 *    appropriate action.
 *    
 * Syntax:
 *    RAPID [-c|--config file] [-x|--xml file] [-l|--log file] [-L|--level N]
 *    RAPID -v|--version
 *    RAPID -?|-h|--help
 *    
 * Thanks to John Burgess of BBN whose code was helpful in creating
 * this class.
 * 
 * @author Brian Lynn <first initial last name at cs.umass.edu>
 * 
 * Copyright 2008 University of Massachusetts, Amherst
 * 
 * Licensed under the Apache License, Version 2.0 (the "License"); you may
 * not use this file except in compliance with the License. You may obtain
 * a copy of the License at
 *    http://www.apache.org/licenses/LICENSE-2.0
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * 
 * Funding for this project was provided by the Defense Advanced Research
 * Projects Agency (DARPA).
 * Distribution Statement A: Approved for public release; distribution
 * unlimited.
 */

import javax.xml.parsers.ParserConfigurationException;
import javax.xml.parsers.SAXParser;
import javax.xml.parsers.SAXParserFactory;
import org.xml.sax.SAXException;
import org.xml.sax.XMLReader;
import java.io.*;
import java.net.*;

public class RAPID extends Thread {
	
	private static final String rapidVersion = "0.9.4";
	
	private static final String defaultLoggingClass = "Console_Logging";
	
	// Configurable values
	private static String multicastGroup = "224.0.0.2";
	private static int multicastPort = 8001;
	private static String xmlSchema = "/etc/router.xsd";
	private static String logConfiguration = null;
	private static int logLevel;
	private static boolean xmlValidate = true;
	protected static String routerEndpoint = "ext.rtr/RAPID";
	protected static String loggingClass = defaultLoggingClass;
	
	// Command line options
	private static String confFile = null;
	private static boolean xmlSchemaOpt = false;
	private static boolean logLevelOpt = false;

	// "Global" values
	protected static Logging log;
	protected static ConfFile routerConf = null;
	protected static String localEID = null;
	protected static Requester requester = null;
	protected static String rapidRegistration = null;
	
	private static Handlers handlerRAPID = null;
	private static RAPID_SAX saxHandler;
	private static SAXParserFactory saxFactory = null;
	private static SAXParser saxParser = null;
	private static XMLReader saxReader = null;
	
	private static final String LOOPBACKADR = "127.0.0.1";
	protected static MulticastSocket dtndSocket = null;
	
	protected static final int MAX_DTNDXML_SZ = 10240;
	
	private static final int THRD_ROUTERLOOP = 0;
	
	
	/**
	 * Constructor initiates the appropriate thread. 
	 */
	RAPID(int thrd) {
		switch (thrd) {
			case THRD_ROUTERLOOP:
				startRouterLoop();
				break;
			default:
				log.error("Attempt to start unkown thread: " + thrd);
				break;
		}
	}
	
	/**
	 * Main thread. Loop waiting for messages from dtnd.
	 */
	private void startRouterLoop() {
		log.info("RAPID external DTN router version: " + rapidVersion);
		log.info("RAPID router started and listening on port " + multicastPort);
		
		byte[] msg = new byte[MAX_DTNDXML_SZ];
		DatagramPacket dgramPacket = new DatagramPacket(msg, msg.length);
		handlerRAPID.initialized();
		while (true) {
			try {
				// Wait for a packet on the loopback multicast socket.
				dtndSocket.receive(dgramPacket);
				if (dgramPacket.getPort() == requester.sourcePort) {
					// We sent the packet -- ignore it.
					continue;
				}
				if (log.enabled(Logging.DEBUG)) {
					log.debug("Packet received from " + 
							dgramPacket.getAddress().toString() +
							":" + dgramPacket.getPort());
				}
				try {
					String s = new String(dgramPacket.getData(), 0, 
							dgramPacket.getLength()).trim();
					log.trace(s);
					saxParser.parse(new ByteArrayInputStream(s.getBytes()),
							saxHandler);
				} catch (SAXException e) {
					if (log.enabled(Logging.ERROR)) {
						log.error("Error parsing XML packet: " + e.getMessage());
					}
					continue;
				} catch (Exception e) {
					if (log.enabled(Logging.ERROR)) {
						log.error("Unanticipated XML parsing error: " + 
								e.getMessage());
					}
					continue;
				}
				
			} catch (SocketTimeoutException e) {
				// We currently don't set a timeout, but ...
				if (log.enabled(Logging.WARN)) {
					log.warn("Socket timeout in main loop");
				}
				continue;
			} catch (Exception e) {
				log.fatal("Unanticipated exception in multicast receive loop: " + 
						e.getMessage());
				break;
			}
			
		}
	}

	/**
	 * @param args Command line arguments.
	 */
	public static void main(String[] args) {
		// Get options.
		parseOpts(args);
		
		// Get values from the configuration file.
		loadConfig();
		
		// Initialize logging to use during execution. Only set
		// the logging level if specified in the command line or RAPID
		// configuration file, otherwise we are content with what the
		// logging system defaults to.
		try {
			log = (Logging) Class.forName(loggingClass).newInstance();
			if (logConfiguration == null) {
				log.conf();
				} else {
			log.conf(logConfiguration);
				}
			if (logLevelOpt) {
				log.setLevel(logLevel);
			} else {
				logLevel = log.getLevel();
			}
		} catch (Exception e) {
			System.err.println("Unable to instantiate or initialize logging: "
					+ e.getMessage());
			System.exit(1);
		}
		
		// Set up our SAX XML handler.
		setupSAX();
		
		// Set up multicast socket that we'll be receiving messages
		// from the DTN daemon on.
		setupMulticast();
		
		// We are now initialized and ready to begin routing. Start the main
		// thread.
		new RAPID(THRD_ROUTERLOOP);
		
	}
	
	/**
	 * We receive XML messages from the DTN daemon on a local multicast
	 * socket. Here we create that socket. We also create the socket to
	 * send messages to the DTN daemon via the Requester class.
	 */
	private static void setupMulticast() {
		try {
			dtndSocket = new MulticastSocket(multicastPort);
			dtndSocket.setReuseAddress(true);
			dtndSocket.setInterface(InetAddress.getByName(LOOPBACKADR));
			dtndSocket.joinGroup(
					new InetSocketAddress(multicastGroup, multicastPort),
					NetworkInterface.getByInetAddress(InetAddress.getByName(LOOPBACKADR)));
			requester = new Requester();
			requester.init(multicastGroup, multicastPort);
		} catch (Exception e) {
			System.err.println("Unable to setup sockets: " +
					e.getMessage());
			System.exit(1);
		}
	}
	
	/**
	 * Initializes the SAX XML handler.
	 */
	private static void setupSAX() {
		// If we're doing validation, make sure the xsd file is there.
		if (xmlValidate && !(new File(xmlSchema).canRead())) {
			System.err.println("XML schema file does not exist or cannot be read: " +
					xmlSchema);
			System.exit(1);
		}
		// Set up the SAX parser/reader and associate it with our handler.
		handlerRAPID = new RAPID_Routing();
		saxHandler = new RAPID_SAX(handlerRAPID);
		saxFactory = SAXParserFactory.newInstance();
		try {
			saxFactory.setValidating(xmlValidate);
			saxFactory.setNamespaceAware(true);
			saxParser = saxFactory.newSAXParser();
			saxReader = saxParser.getXMLReader();
			saxReader.setErrorHandler(saxHandler);
			saxReader.setContentHandler(saxHandler);
		} catch (ParserConfigurationException e) {
			System.err.println(
					"SAX parser does not support requested configuration: " +
					e.getMessage());
			System.exit(1);
		} catch (SAXException  e) {
			System.err.println(
					"Unanticpated SAX parser exception: " +
					e.getMessage());
		} catch (Exception e) {
			System.err.println("Unanticipated exception: " + e.getMessage());
			System.exit(1);
		}
		// If validation is enabled, set it up.
		if (xmlValidate) {
			try {
				saxReader.setFeature("http://xml.org/sax/features/validation",
						true);
				saxReader.setFeature("http://apache.org/xml/features/validation/schema",
						 true);
				saxReader.setFeature(
						"http://apache.org/xml/features/validation/schema-full-checking",
						true);
				saxReader.setProperty(
						"http://apache.org/xml/properties/schema/external-noNamespaceSchemaLocation",
						xmlSchema);
			} catch (Exception e)  {
				System.err.println("Unable to configure XML validation: " +
						e.getMessage());
				System.exit(1);
			}
		}
	}
	
	/**
	 * If a configuration file is specified, read the values.
	 * Command line arguments take precedence over configuration
	 * file values, i.e. if passed on the command line don't look
	 * for it in the configuration file.
	 */
	private static void loadConfig() {
		if (confFile != null) {
			routerConf = new ConfFile(confFile);
			if (routerConf.parse()) {
				loggingClass = routerConf.getString("loggingClass", defaultLoggingClass);
				routerEndpoint = routerConf.getString("routerEndpoint", routerEndpoint);
				multicastGroup = routerConf.getString("multicastGroup", multicastGroup);
				multicastPort = routerConf.getInt("multicastPort", multicastPort);
				xmlValidate = routerConf.getBoolean("xmlValidate", xmlValidate);
				if (!xmlSchemaOpt) {
					xmlSchema = routerConf.getString("xmlSchema", xmlSchema);
				}
				if (logConfiguration == null) {
					logConfiguration = routerConf.getString("logConfiguration", null);
				}
				if (!logLevelOpt) {
					if (routerConf.exists("logLevel")) {
						logLevel = routerConf.getInt("logLevel", Logging.WARN);
						logLevelOpt = true;
					}
				}
			} else {
				System.exit(1);
			}
		} else {
			// "Empty" configuration file.
			routerConf = new ConfFile();
		}
	}
	
	/**
	 * Parses the command line options. These should be kept to a minimum;
	 * use the configuration file.
	 * 
	 * @param args Arguments passed in at runtime.
	 */
	private static void parseOpts(String args[]) {
		int x = 0;
		while (x < args.length) {
			String arg = args[x++];
			try {
				if (arg.equals("-c") || arg.equals("--config")) {
					confFile = args[x++];
				} else if (arg.equals("-x") || arg.equals("--xml")) {
					xmlSchema = args[x++];
					xmlSchemaOpt = true;
				} else if (arg.equals("-l") || arg.equals("--log")) {
					logConfiguration = args[x++];
				} else if (arg.equals("-L") || arg.equals("--level")) {
					logLevel = Integer.parseInt(args[x++]);
					logLevelOpt = true;
				} else if (arg.equals("-v") || arg.equals("--version")) {
					versionExit();
				} else if (arg.equals("-h") || arg.equals("-?") || arg.equals("--help")) {
					helpExit();
				} else {
					System.err.println("Unknown option: " + arg);
					System.exit(1);
				}
			} catch (NumberFormatException e) {
				System.err.println("Invalid integer parameter for option: " + arg);
				System.exit(1);
			} catch (Exception e) {
				System.err.println("Missing parameter after option: " + arg);
				System.exit(1);
			}
		}
	}
	
	/**
	 * Print the version and exit the program.
	 */
	private static void versionExit() {
		System.out.println("RAPID Version: " + rapidVersion);
		System.exit(0);
	}
	
	/**
	 * Prints help text and then terminates the program.
	 */
	private static void helpExit() {
		System.out.println(
			"\n" +
			"RAPID [-c|--config file] [-x|--xml file] [-l|--log file] [-L|--level N]\n" +
			"RAPID -v|--version\n" +
			"RAPID -?|-h|--help\n" +
			"\n" +
			"   -c         Specifies the RAPID configuration file to be used.\n" +
			"   --config   Default is no configuration file.\n" +
			"\n" +
			"   -x         Router XML schema file. Default is /etc/router.xsd.\n" +
			"   --xml\n" +
			"\n" +
			"   -l         Logging configuration file. Default is defined by the\n" +
			"   --log      configured logging subsystem.\n" +
			"\n" +
			"   -L         Logging level to be used (0-6). See documentation for\n" +
			"   --level    the meaning of the values, though 0 is verbose logging\n" +
			"              and 6 suppresses logging.\n" +
			"\n" +
			"   -v         Print the RAPID version number and exit.\n" +
			"   --version\n" + 
			"\n" +
			"   -? | -h    Print this help text and exit.\n" +
			"   --help\n"
			);
		System.exit(0);
	}
	
	/**
	 * Sets the local EID, used by all, as well as the router endpoint name.
	 * 
	 * @param eid The local EID.
	 */
	protected static void setLocalEID(String eid) {
		localEID = eid;
		rapidRegistration = eid + "/" + routerEndpoint;
	}
	
}
