           RAPID: AN EXTERNAL ROUTER FOR DTN2

           http://prisms.cs.umass.edu/rapid/

                      Brian Lynn
        <first initial last name at cs.umass.edu>
           University of Massachusetts, Amherst
                    November 20, 2008


NOTICE

Copyright 2008 University of Massachusetts, Amherst.

RAPID is licensed under the Apache License, Version 2.0 (the 
"License"); you may not use RAPID except in compliance with the 
License. You may obtain a copy of the License at

http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, 
software distributed under the License is distributed on an "AS 
IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either 
express or implied. See the License for the specific language 
governing permissions and limitations under the License.

The development of RAPID was supported by Defense Advanced 
Research Projects Agency (DARPA) grant W15P7T-05-C-P213. 
Distribution Statement A: Approved for public release; 
distribution unlimited.


INTRODUCTION

The Resource Allocation Protocol for Intentional DTN, or RAPID, 
is a routing algorithm for disruption-tolerant networks [1]. We 
have implemented RAPID for the Delay-Tolerant Networking Research 
Group's DTN reference implementation (DTN2) [2].

The RAPID algorithm was a result of research performed on 
DieselNet [3], a mobile network test bed developed by the 
University of Massachusetts, Amherst. A defining characteristic 
of a mobile network such as DieselNet is that on any given day 
nodes may have contact with only a subset of the other nodes, and 
that contact may be infrequent and for very brief periods of 
time. The RAPID algorithm was designed to effectively route data 
in a mobile network. A feature of RAPID is that it functions by 
optimizing for a specific routing metric. In our DTN2 
implementation of RAPID, the metric is to minimize the delivery 
time for all DTN2 bundles.

RAPID executes as an external DTN2 router, using DTN2's XML-based 
External Router Interface. RAPID is implemented in Java. 


FILES AND DIRECTORIES

RAPID requires the DTN2 external router schema file. By default, 
DTN2 installs the file as /etc/router.xsd.

RAPID exchanges a meta data bundle when it comes into contact 
with an instance of the RAPID router running on another node. In 
order for RAPID to be able to read a received meta data bundle's 
payload, RAPID must have read access to the DTN2 bundle 
directory. The directory is often named /var/dtn/bundles.

RAPID periodically writes to a persistent file which bundles are 
known to have been delivered. By default, RAPID writes to a file 
named /var/rapid_router/acks. Therefore RAPID will need read and 
write access to the /var/rapid_router directory. The location of 
the file may be overridden in the RAPID configuration file. It is 
also possible to disable this functionality.

BUILDING AND INSTALLING THE RAPID ROUTER

You should have Java 5.0 (a.k.a. 1.5.0) or later installed on 
your system. To build and install RAPID for DTN2:

    $ Untar the files: tar zxf rapid_router-0.9.4.tar.gz (or 
      whatever the file is named)
    $ cd rapid_router
    $ ./install.sh

The install script will prompt you to build RAPID if necessary, 
and it will also ask you questions about what directories to use. 
The script should work regardless of whether you have RAPID 
source or a pre-built distribution.

You can use make to build RAPID by simply typing:

    $ make

The syntax for installing RAPID is:

    Make install [ INSTALLDIR=<directory> ] [ACKSDIR=<directory> ] 

To install RAPID in its default location, 
/usr/local/rapid_router, using /var/rapid_router for check 
pointing delivered bundles:

    $ make install

To install RAPID in a different directory

    $ make install INSTALLDIR=<directory>

Make will create the ACKSDIR, though there are no files to copy 
to the directory. You will need to define the file's path in the 
RAPID configuration file if using a checkpoint file other than 
/var/rapid_router/acks.


RUNNING RAPID

You should have DTN2 installed on your system. RAPID was developed
and tested with DTN 2.5, but appears to work fine with DTN 2.6.
Due to limitations in the DTN2 external router interface, RAPID
should be started before starting the DTN2 daemon, dtnd. Once
RAPID is running, it interacts solely with the DTN2 daemon.

When RAPID is installed, a script that runs Java with the RAPID 
JAR is also installed. The syntax of the RAPID command is:

    RAPID [-c|--config file] [-x|--xml file] [-l|--log file]
          [-L|--level N]
    RAPID -v|--version
    RAPID -?|-h|--help

where

    -c, --config   Specifies a file containing RAPID 
                   configuration values. The default is to
                   have no configuration file and to use all
                   default values.
    -x, --xml      Specifies the XML schema definition file that 
                   defines the XML messages exchanged between
                   RAPID and the DTN2 daemon. The default is
                   /etc/router.xsd. The schema file is provided
                   by DTN2.
    -l, --log      Defines a logging configuration file. This 
                   configuration file is specific to the logging
                   class being used. By default, RAPID does not
                   require a logging configuration file. If you
                   are using the Apache log4j logger then its
                   configuration file can be specified here.
    -L, --level    Specifies logging verbosity, where 0 is all 
                   messages are to be logged and 6 is no messages
                   are to be logged.
    -v, --version  Tells RAPID to print its version number and
                   then exit.
    -?,-h,--help   Instructs RAPID to output some brief help 
                   text and then exit.      

The RAPID configuration file is discussed in more detail later in 
this document.


RAPID LOGGING

RAPID comes with two implementations of its logging class. By 
default, it uses the Console_Logging class which simply logs 
messages to stdout. RAPID also supports the Apache log4j logger, 
which provides greater flexibility over where output is logged. 
To use the Apache log4j logger:

    * Download the log4j JAR file from 
      http://logging.apache.org/log4j/1.2/download.html. Install 
      it on your system, if it is not already installed.
    * Edit src/Makefile to build Log4j_Logging.
    * Edit the RAPID script so the Java -classpath references the 
      JAR file.
    * Rebuild and re-install RAPID.
    * Add a line to the RAPID configuration file: 
         loggingClass=Log4j_Logging
    * Specify the RAPID configuration file when running RAPID.
    * Optionally, use the --log parameter when running RAPID to 
      reference your log4j configuration file.

The logging level can be defined by the --level parameter of the 
RAPID command. Specifying a level enables output of logging 
messages at or above that level. RAPID uses the logging levels 
defined by Apache log4j.

    0 - Tracing messages.
    1 - Debugging messages.
    2 - Informational messages.
    3 - Warnings.
    4 - Errors.
    5 - Fatal error messages.
    6 - This level results in no messages being logged.

If using the Console_Logging class the default level is 4, 
warnings.


DTN2 CONFIGURATION

Important: RAPID requires that the DTN2 configuration file -- 
normally /etc/dtn.conf -- include the following line:

    param set early_deletion false

If this option is not set then DTN2 may delete bundles after they 
have been initially sent, preventing RAPID from replicating 
bundles.

You also need to make certain that DTN2 is configured to use an
external router:

    route set type external

RAPID also assumes that DTN2 is configured to open and close 
links as nodes come in and out of contact. This may include using 
a discovery protocol. The RAPID_Policy class supports the ability 
to add a simple link management class.


RAPID ROUTING AND IMPLEMENTATION OVERVIEW

[See the pdf version of this documentation.]


RAPID CLASSES

[See the pdf version of this documentation.]


CONFIGURING RAPID

[See the pdf version of this documentation, or the supplied
example configuration file.]


REFERENCES

[1] A. Balasubramanian, B. N. Levine, and A. Venkataramani. DTN 
Routing as a Resource Allocation Problem. In Proceedings of ACM 
SiIGCOMM, August 2007.

[2] Delay Tolerant Networking Group, http://www.dtnrg.org.

[3] UMass DieselNet, 
http://prisms.cs.umass.edu/dome/index.php?page=umassdieselnet.
